/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowRight, ArrowUpRight, Check, Shield, Activity, Calendar, DollarSign,
  CheckCircle, MessageSquare, Clock, Sparkles, Star, MapPin, Mail, Phone,
  Briefcase, Layers, Heart, Laptop, Award, FileText, ChevronRight, Play, Users, Target, Send
} from 'lucide-react';

import { Project, Client, Service, BlogPost, Testimonial, Lead, StripeSubscription, AnalyticsStats } from './types';
import {
  loadCMSData, saveCMSData,
  INITIAL_PROJECTS, INITIAL_CLIENTS, INITIAL_SERVICES, INITIAL_BLOG_POSTS, INITIAL_TESTIMONIALS, INITIAL_LEADS, INITIAL_SUBSCRIPTIONS, INITIAL_ANALYTICS, INDUSTRIES
} from './data/cmsData';

import Navbar from './components/Navbar';
import Footer from './components/Footer';
import AdminPortal from './components/AdminPortal';
import StripeCheckout from './components/StripeCheckout';
import ServiceDetailView from './components/ServiceDetailView';

export default function App() {
  // --- CORE STATE (Cached in LocalStorage) ---
  const [projects, setProjects] = useState<Project[]>(() => loadCMSData('projects', INITIAL_PROJECTS));
  const [clients, setClients] = useState<Client[]>(() => loadCMSData('clients', INITIAL_CLIENTS));
  const [services, setServices] = useState<Service[]>(() => loadCMSData('services', INITIAL_SERVICES));
  const [blogs, setBlogs] = useState<BlogPost[]>(() => loadCMSData('blogs', INITIAL_BLOG_POSTS));
  const [testimonials, setTestimonials] = useState<Testimonial[]>(() => loadCMSData('testimonials', INITIAL_TESTIMONIALS));
  const [leads, setLeads] = useState<Lead[]>(() => loadCMSData('leads', INITIAL_LEADS));
  const [subscriptions, setSubscriptions] = useState<StripeSubscription[]>(() => loadCMSData('subscriptions', INITIAL_SUBSCRIPTIONS));
  const [analytics, setAnalytics] = useState<AnalyticsStats>(() => loadCMSData('analytics', INITIAL_ANALYTICS));

  // --- ROUTING / NAVIGATION STATE ---
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);
  const [selectedBlogId, setSelectedBlogId] = useState<string | null>(null);

  // --- ADMINISTRATIVE STATE ---
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('techrooot_admin_session') === 'active';
  });
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);

  // --- SYNC ACTIONS ---
  useEffect(() => {
    saveCMSData('projects', projects);
  }, [projects]);

  useEffect(() => {
    saveCMSData('clients', clients);
  }, [clients]);

  useEffect(() => {
    saveCMSData('services', services);
  }, [services]);

  useEffect(() => {
    saveCMSData('blogs', blogs);
  }, [blogs]);

  useEffect(() => {
    saveCMSData('testimonials', testimonials);
  }, [testimonials]);

  useEffect(() => {
    saveCMSData('leads', leads);
  }, [leads]);

  useEffect(() => {
    saveCMSData('subscriptions', subscriptions);
  }, [subscriptions]);

  useEffect(() => {
    saveCMSData('analytics', analytics);
  }, [analytics]);

  // Navigate helper that resets detail states
  const handleNavigate = (page: string, subId: string | null = null) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    if (page === 'case-study' && subId) {
      setCurrentPage(page);
      setSelectedProjectId(subId);
    } else if (page === 'service-detail' && subId) {
      setCurrentPage('services');
      setSelectedServiceId(subId);
    } else if (page === 'services') {
      setCurrentPage('services');
      setSelectedServiceId(subId); // if null shows list, if subId shows detail
      setSelectedProjectId(null);
      setSelectedBlogId(null);
    } else if (page === 'blog-detail' && subId) {
      setCurrentPage(page);
      setSelectedBlogId(subId);
    } else {
      setCurrentPage(page);
      setSelectedProjectId(null);
      setSelectedServiceId(null);
      setSelectedBlogId(null);
    }
  };

  const handleAdminLoginSuccess = () => {
    setIsAdminLoggedIn(true);
    localStorage.setItem('techrooot_admin_session', 'active');
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    localStorage.removeItem('techrooot_admin_session');
    handleNavigate('home');
  };

  const handleSubscriptionCreated = (newSub: StripeSubscription) => {
    const updatedSubs = [...subscriptions, newSub];
    setSubscriptions(updatedSubs);
    
    // Also log a direct Lead based on the subscribed account
    const newLead: Lead = {
      id: `lead-sub-${Date.now()}`,
      name: newSub.clientName,
      email: newSub.email,
      company: 'Retainer Client',
      serviceType: `Subscribed: ${newSub.planName}`,
      message: `System checkout authorized successfully. Retainer value: $${newSub.amount}/${newSub.interval}. Status active. Onboarding checklist dispatched automatically.`,
      status: 'New',
      timestamp: new Date().toISOString()
    };
    setLeads(prev => [newLead, ...prev]);

    // Force traffic metrics to tick up as visual reward
    setAnalytics(prev => ({
      ...prev,
      visitors: prev.visitors + 1,
      totalLeads: prev.totalLeads + 1,
      activeSubscriptions: prev.activeSubscriptions + 1,
      monthlyRevenue: prev.monthlyRevenue + newSub.amount
    }));
  };

  // Contact form submission logic
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formCompany, setFormCompany] = useState('');
  const [formService, setFormService] = useState('Website Development');
  const [formMessage, setFormMessage] = useState('');
  const [contactSuccess, setContactSuccess] = useState(false);

  // Simulated Calendly Scheduler
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formEmail || !formMessage) return;

    const newLead: Lead = {
      id: `lead-${Date.now()}`,
      name: formName,
      email: formEmail,
      company: formCompany,
      serviceType: formService,
      message: formMessage,
      status: 'New',
      timestamp: new Date().toISOString()
    };

    setLeads(prev => [newLead, ...prev]);
    setContactSuccess(true);
    
    // Reset form
    setFormName('');
    setFormEmail('');
    setFormCompany('');
    setFormMessage('');
    
    setTimeout(() => setContactSuccess(false), 5000);
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDate || !selectedTime) return;

    const bookingMessage = `Simulated consultation scheduled via interactive calendar on ${selectedDate} at ${selectedTime}. Confirmed.`;
    const newLead: Lead = {
      id: `booking-${Date.now()}`,
      name: formName || 'Scheduled Guest',
      email: formEmail || 'guest@company.com',
      company: formCompany || 'Inbound Partner',
      serviceType: formService || 'Growth Discovery Call',
      message: bookingMessage,
      status: 'New',
      timestamp: new Date().toISOString()
    };

    setLeads(prev => [newLead, ...prev]);
    setBookingSuccess(true);
    
    setTimeout(() => {
      setBookingSuccess(false);
      setSelectedDate('');
      setSelectedTime('');
    }, 5000);
  };

  // Before/After comparison active slider project
  const [activeBeforeAfterId, setActiveBeforeAfterId] = useState<string>('nomad-nest');

  return (
    <div className="bg-brand-bg text-zinc-100 min-h-screen selection:bg-brand-accent selection:text-black overflow-hidden relative">
      
      {/* Background Subtle Watermark Textures */}
      <div className="absolute top-12 right-0 p-12 opacity-[0.02] select-none pointer-events-none z-0">
        <span className="text-[250px] font-black leading-none uppercase tracking-tighter">Root</span>
      </div>

      {/* Absolute background visual ambient glows */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-brand-accent/5 rounded-full blur-[120px] pointer-events-none z-0" />
      <div className="absolute top-[1200px] right-10 w-[400px] h-[400px] bg-brand-accent/3 rounded-full blur-[100px] pointer-events-none z-0" />

      {/* Global Navigation Header */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        isAdminLoggedIn={isAdminLoggedIn}
        onLogoutAdmin={handleAdminLogout}
      />

      {/* Main Page Layout Content Router */}
      <main className="relative z-10">
        <AnimatePresence mode="wait">
          
          {/* =========================================================================
              1) HOME PAGE
             ========================================================================= */}
          {currentPage === 'home' && (
            <motion.div
              key="home-page"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="flex flex-col"
            >
              {/* Cinematic Hero Section */}
              <section id="hero" className="min-h-screen flex flex-col justify-center pt-32 pb-20 relative px-6 overflow-hidden">
                <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  
                  {/* Left Column: Bold Typography & Main Call to Action */}
                  <div className="lg:col-span-7 flex flex-col gap-6">
                    <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-brand-accent/10 text-brand-accent border border-brand-accent/20 self-start">
                      <span className="w-1.5 h-1.5 bg-brand-accent rounded-full animate-pulse" />
                      <span className="text-[10px] font-mono tracking-widest uppercase font-bold">Built for Conversion</span>
                    </div>

                    <h1 className="font-display font-black text-6xl sm:text-7xl xl:text-[85px] leading-[0.9] uppercase tracking-tighter text-white">
                      We Build <br/>
                      <span className="text-transparent stroke-white" style={{ WebkitTextStroke: '1.5px white' }}>Digital Brands</span><br/>
                      People Remember.
                    </h1>

                    <p className="text-base sm:text-lg text-zinc-400 font-light leading-relaxed max-w-xl">
                      TechRooot is an elite growth partner helping businesses multiply revenue through bespoke high-conversion websites, expert LinkedIn executive management, Superhost Airbnb operations, and custom AI automations.
                    </p>

                    <div className="flex flex-wrap items-center gap-4 mt-2">
                      <button
                        id="hero-cta-view-work"
                        onClick={() => handleNavigate('work')}
                        className="flex items-center gap-2 bg-white text-black font-bold px-8 py-4.5 rounded-sm text-xs uppercase tracking-wider hover:bg-brand-accent hover:shadow-[0_0_25px_rgba(163,230,53,0.3)] transition-all duration-300 cursor-pointer"
                      >
                        View Our Work
                        <ArrowRight className="w-4 h-4" />
                      </button>
                      
                      <button
                        id="hero-cta-book-call"
                        onClick={() => handleNavigate('contact')}
                        className="flex items-center gap-2 bg-transparent hover:bg-white/10 border border-white/20 text-white font-bold px-8 py-4.5 rounded-sm text-xs uppercase tracking-wider transition-all cursor-pointer"
                      >
                        Book a Call
                        <ArrowUpRight className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Quick Trust Statistics Row */}
                    <div className="grid grid-cols-3 gap-6 border-t border-zinc-900 pt-10 mt-6 max-w-lg">
                      <div>
                        <span className="block font-display font-bold text-2xl sm:text-3xl text-white">94%</span>
                        <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Airbnb Occupancy</span>
                      </div>
                      <div>
                        <span className="block font-display font-bold text-2xl sm:text-3xl text-white">+210%</span>
                        <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Web Bookings Lift</span>
                      </div>
                      <div>
                        <span className="block font-display font-bold text-2xl sm:text-3xl text-white">340k+</span>
                        <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">LinkedIn Views</span>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Hero Visual Asset Teaser Card */}
                  <div className="lg:col-span-5 relative">
                    <div className="relative bg-zinc-900/60 border border-white/10 rounded-2xl p-6 shadow-3xl overflow-hidden group">
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80 z-10 pointer-events-none" />
                      
                      <div className="relative rounded-xl overflow-hidden mb-6 border border-white/5 h-64">
                        <img
                          src="https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&q=80&w=600"
                          alt="Nomad Nest Premium Airbnb"
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-brand-accent/5 mix-blend-color opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>

                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-mono text-brand-accent uppercase tracking-widest font-bold">Featured Case Study</span>
                        <span className="text-xs text-white/40 font-mono">Kyoto Hospitality</span>
                      </div>

                      <h3 className="font-display font-bold text-2xl text-white mb-2 group-hover:text-brand-accent transition-colors">Nomad Nest</h3>
                      <p className="text-xs text-white/60 font-light leading-relaxed mb-4">
                        Rebranding & Automated Booking Funnel for Luxury Airbnbs.
                      </p>

                      <div className="mt-4 flex gap-10 border-t border-white/10 pt-4">
                        <div>
                          <p className="text-[10px] text-white/40 uppercase mb-1">Increase</p>
                          <p className="text-xl font-bold text-white">+210%</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-white/40 uppercase mb-1">Occupancy</p>
                          <p className="text-xl font-bold text-brand-accent">94%</p>
                        </div>
                      </div>

                      <button
                        onClick={() => handleNavigate('case-study', 'nomad-nest')}
                        className="mt-6 flex items-center gap-1.5 text-xs text-white hover:text-brand-accent transition-colors font-mono cursor-pointer z-20 relative"
                      >
                        Read Dynamic Case Study <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                </div>

                {/* Clients Scrolling Strip */}
                <div className="max-w-7xl mx-auto w-full mt-24 border-t border-zinc-900 pt-8 flex flex-col gap-4">
                  <span className="text-xs font-mono text-zinc-500 uppercase tracking-widest text-center sm:text-left">Trusted by high-growth founders and real-estate groups</span>
                  <div className="flex flex-wrap items-center justify-center sm:justify-between gap-8 opacity-60">
                    <span className="font-display font-bold tracking-tight text-lg text-zinc-400">NOMAD NEST</span>
                    <span className="font-display font-bold tracking-tight text-lg text-zinc-400">AURA CLINICS</span>
                    <span className="font-display font-bold tracking-tight text-lg text-zinc-400">APEX CAPITAL</span>
                    <span className="font-display font-bold tracking-tight text-lg text-zinc-400">SUSTAIN AI</span>
                  </div>
                </div>
              </section>

              {/* Service Capabilities Overview */}
              <section id="services-teaser" className="py-24 border-t border-zinc-900 px-6">
                <div className="max-w-7xl mx-auto">
                  <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 mb-16">
                    <div className="max-w-xl">
                      <span className="text-xs font-mono font-bold uppercase tracking-widest text-brand-accent">Our Capabilities</span>
                      <h2 className="font-display font-semibold text-3xl sm:text-4xl text-white tracking-tight mt-3">
                        How We Help You Grow
                      </h2>
                    </div>
                    <button
                      onClick={() => handleNavigate('services')}
                      className="flex items-center gap-1.5 text-sm font-mono text-zinc-400 hover:text-white transition-colors cursor-pointer"
                    >
                      Explore All 6 Core Divisions <ChevronRight className="w-4 h-4 text-brand-accent" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {services.slice(0, 3).map((serv) => (
                      <div
                        key={serv.id}
                        onClick={() => handleNavigate('services', serv.id)}
                        className="group bg-zinc-900/40 hover:bg-zinc-900 border border-zinc-900 hover:border-zinc-800 p-8 rounded-2xl transition-all duration-300 cursor-pointer flex flex-col justify-between"
                      >
                        <div>
                          <div className="w-10 h-10 rounded-xl bg-brand-accent/5 border border-brand-accent/10 flex items-center justify-center text-brand-accent mb-6 group-hover:scale-105 transition-transform">
                            {serv.category === 'tech' ? <Laptop className="w-5 h-5" /> : 
                             serv.category === 'growth' ? <Activity className="w-5 h-5" /> :
                             <Sparkles className="w-5 h-5" />}
                          </div>
                          <h3 className="font-display font-bold text-lg text-white mb-3 group-hover:text-brand-accent transition-colors">{serv.title}</h3>
                          <p className="text-xs text-zinc-400 font-light leading-relaxed mb-6">{serv.description}</p>
                        </div>
                        <span className="flex items-center gap-1 text-xs font-mono text-zinc-500 group-hover:text-white transition-colors">
                          Learn about deliverables <ChevronRight className="w-3 h-3 text-brand-accent" />
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              {/* Founder Story Teaser */}
              <section id="founder-teaser" className="py-24 border-t border-zinc-900 px-6 bg-zinc-900/20 relative">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(163,230,53,0.03),transparent)] pointer-events-none" />
                <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  
                  {/* Left Bio Card */}
                  <div className="lg:col-span-5 relative">
                    <div className="glass-panel border border-zinc-800 rounded-3xl p-6">
                      <div className="flex items-center gap-4 mb-6">
                        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-brand-accent to-[#65a30d] flex items-center justify-center font-display font-bold text-xl text-black">
                          TR
                        </div>
                        <div>
                          <h4 className="font-display font-bold text-white">Arpan G.</h4>
                          <p className="text-xs text-zinc-500 font-mono">Founding Director, TechRooot</p>
                        </div>
                      </div>

                      <blockquote className="text-sm font-light text-zinc-300 leading-relaxed italic mb-4">
                        "The modern creative agency is fundamentally broken. They produce aesthetic templates that convert zero leads, or run ad budgets without mathematical economic targets. TechRooot was built as a unified studio to deliver real, measurable commercial margins."
                      </blockquote>

                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-500" />
                        <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">Expertise certified over 100+ projects</span>
                      </div>
                    </div>
                  </div>

                  {/* Right Narrative Copy */}
                  <div className="lg:col-span-7 flex flex-col gap-5">
                    <span className="text-xs font-mono font-bold uppercase tracking-widest text-brand-accent">Human Positioning</span>
                    <h2 className="font-display font-semibold text-3xl sm:text-4xl text-white tracking-tight">
                      Why We Built TechRooot
                    </h2>
                    
                    <p className="text-sm text-zinc-400 font-light leading-relaxed">
                      We observed that scaling founders and short-term real estate investors face a common bottleneck: they have outstanding services or assets, but struggle to package them with the premium visual identity and systematic pipeline needed to attract high-paying clients.
                    </p>

                    <p className="text-sm text-zinc-400 font-light leading-relaxed">
                      TechRooot steps in as an integrated Growth Studio. Instead of hiring three different freelancers, we provide custom design, flawless React engineering, automated operational pipelines, and mathematical lead gen under one continuous retainer.
                    </p>

                    <button
                      onClick={() => handleNavigate('about')}
                      className="flex items-center gap-1.5 text-xs font-mono font-semibold text-white hover:text-brand-accent transition-colors self-start cursor-pointer mt-2"
                    >
                      Our Complete Story & Timeline <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>

                </div>
              </section>

              {/* Call to Action Retainer Section */}
              <section className="py-24 border-t border-zinc-900 px-6 text-center max-w-4xl mx-auto flex flex-col items-center gap-6">
                <span className="text-xs font-mono text-zinc-500 uppercase tracking-widest">Pricing Retainers</span>
                <h2 className="font-display font-semibold text-3xl sm:text-4xl text-white tracking-tight">Ready to double your revenue?</h2>
                <p className="text-sm text-zinc-400 font-light max-w-xl leading-relaxed">
                  Unlock transparent pricing packages and set up your growth campaign securely with Stripe today.
                </p>
                <button
                  id="home-open-stripe-checkout-btn"
                  onClick={() => setIsCheckoutOpen(true)}
                  className="flex items-center gap-2 bg-white text-black px-8 py-4 rounded-xl font-bold hover:bg-brand-accent hover:shadow-[0_0_20px_rgba(245,158,11,0.3)] transition-all cursor-pointer"
                >
                  <DollarSign className="w-4 h-4" />
                  View Studio Packages
                </button>
              </section>

            </motion.div>
          )}

          {/* =========================================================================
              2) ABOUT PAGE
             ========================================================================= */}
          {currentPage === 'about' && (
            <motion.div
              key="about-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-5xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-16"
            >
              {/* Header */}
              <div className="flex flex-col gap-4 max-w-xl">
                <span className="text-xs font-mono text-brand-accent uppercase tracking-widest">Our Story & Mission</span>
                <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight leading-none">
                  A Creative Studio Engineered for Trust
                </h1>
                <p className="text-base text-zinc-400 font-light leading-relaxed">
                  TechRooot is an original growth studio that merges premium editorial storytelling with strict, mathematical system automation.
                </p>
              </div>

              {/* Core Pillars / Values Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-zinc-900/40 border border-zinc-900 p-8 rounded-2xl">
                  <span className="font-display font-bold text-white text-lg">1. Zero Bloat Philosophy</span>
                  <p className="text-xs text-zinc-400 font-light leading-relaxed mt-3">
                    We hate bloated templates and cheap stock patterns. We build optimized custom platforms and authentic, high-value LinkedIn thoughts tailored to your precise experience.
                  </p>
                </div>
                <div className="bg-zinc-900/40 border border-zinc-900 p-8 rounded-2xl">
                  <span className="font-display font-bold text-white text-lg">2. Financial Integrity</span>
                  <p className="text-xs text-zinc-400 font-light leading-relaxed mt-3">
                    We treat your ad budget like our own capital. Every Meta, Google, and LinkedIn campaign runs with explicit customer lifetime value calculations and target acquisition cost ratios.
                  </p>
                </div>
                <div className="bg-zinc-900/40 border border-zinc-900 p-8 rounded-2xl">
                  <span className="font-display font-bold text-white text-lg">3. Absolute Ownership</span>
                  <p className="text-xs text-zinc-400 font-light leading-relaxed mt-3">
                    No middlemen or slow agencies. We serve as a direct expansion of your founding executive circle, aligning our performance targets directly with your commercial bottom line.
                  </p>
                </div>
              </div>

              {/* Timeline Sequence */}
              <div className="flex flex-col gap-8">
                <h3 className="font-display font-bold text-xl text-white pb-3 border-b border-zinc-900">How We Evolved</h3>
                
                <div className="relative border-l border-zinc-800 pl-6 ml-4 flex flex-col gap-8">
                  {/* Node 1 */}
                  <div className="relative">
                    <div className="absolute -left-[31px] top-1.5 w-4.5 h-4.5 rounded-full bg-brand-accent border-4 border-zinc-950" />
                    <span className="text-xs font-mono text-zinc-500">2024 • THE SCRATCHPAD</span>
                    <h4 className="text-base font-semibold text-white mt-1">Founding & Web Consultation</h4>
                    <p className="text-xs text-zinc-400 font-light mt-1 max-w-2xl leading-relaxed">
                      TechRooot launched as a custom dev boutique, engineering fast-loading consultation pages and scheduling tools for local service providers.
                    </p>
                  </div>

                  {/* Node 2 */}
                  <div className="relative">
                    <div className="absolute -left-[31px] top-1.5 w-4.5 h-4.5 rounded-full bg-zinc-800 border-4 border-zinc-950" />
                    <span className="text-xs font-mono text-zinc-500">2025 • THE MULTIPLICATION</span>
                    <h4 className="text-base font-semibold text-white mt-1">Expanding Hospitality & Branding Retainers</h4>
                    <p className="text-xs text-zinc-400 font-light mt-1 max-w-2xl leading-relaxed">
                      By integrating dynamic automated pricing tools for premium Airbnbs and managing executive LinkedIn profiles, we transformed client properties into highly yielding hospitality operations.
                    </p>
                  </div>

                  {/* Node 3 */}
                  <div className="relative">
                    <div className="absolute -left-[31px] top-1.5 w-4.5 h-4.5 rounded-full bg-brand-accent animate-pulse border-4 border-zinc-950" />
                    <span className="text-xs font-mono text-brand-accent">2026 • THE NOW</span>
                    <h4 className="text-base font-semibold text-white mt-1">Autonomous AI Systems & Performance Advertising</h4>
                    <p className="text-xs text-zinc-400 font-light mt-1 max-w-2xl leading-relaxed">
                      Today, TechRooot scales founders holistically. We deploy intelligent AI lead parsers, construct custom client databases, manage global ad campaigns, and support startup scale stages globally.
                    </p>
                  </div>
                </div>
              </div>

            </motion.div>
          )}

          {/* =========================================================================
              3) SERVICES PAGE (With Dynamic Service Detail View!)
             ========================================================================= */}
          {currentPage === 'services' && (
            <motion.div
              key="services-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-5xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-12"
            >
              {selectedServiceId === null ? (
                <>
                  {/* Services Directory List */}
                  <div className="flex flex-col gap-4 max-w-xl mb-6">
                    <span className="text-xs font-mono text-brand-accent uppercase tracking-widest">Our Capabilities</span>
                    <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight">
                      Engineered Services for High-Growth Brands
                    </h1>
                    <p className="text-sm text-zinc-400 font-light leading-relaxed">
                      Choose an offering below to explore our detailed process, deliverables, and sample results.
                    </p>
                  </div>

                  {/* Services Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {services.map((serv) => (
                      <div
                        key={serv.id}
                        onClick={() => setSelectedServiceId(serv.id)}
                        className="group bg-zinc-900/40 hover:bg-zinc-900 border border-zinc-900 hover:border-zinc-800 p-8 rounded-3xl transition-all duration-300 cursor-pointer flex flex-col justify-between"
                      >
                        <div>
                          <div className="w-10 h-10 rounded-xl bg-zinc-950 border border-zinc-800/80 flex items-center justify-center text-brand-accent mb-6 group-hover:scale-105 transition-transform">
                            {serv.category === 'tech' ? <Laptop className="w-5 h-5" /> : 
                             serv.category === 'growth' ? <Activity className="w-5 h-5" /> :
                             serv.category === 'marketing' ? <Target className="w-5 h-5" /> :
                             <Sparkles className="w-5 h-5" />}
                          </div>
                          <h3 className="font-display font-bold text-xl text-white mb-3 group-hover:text-brand-accent transition-colors">{serv.title}</h3>
                          <p className="text-xs text-zinc-400 font-light leading-relaxed mb-6">{serv.description}</p>
                        </div>
                        <span className="flex items-center gap-1 text-xs font-mono text-zinc-500 group-hover:text-white transition-colors pt-4 border-t border-zinc-800/50 mt-2">
                          View pricing & process <ArrowRight className="w-3.5 h-3.5 text-brand-accent" />
                        </span>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                /* Dynamic Service Sub-Page View! */
                (() => {
                  const s = services.find(serv => serv.id === selectedServiceId);
                  if (!s) return null;
                  return (
                    <ServiceDetailView
                      service={s}
                      projects={projects}
                      onBack={() => setSelectedServiceId(null)}
                      onNavigate={handleNavigate}
                      setLeads={setLeads}
                      setAnalytics={setAnalytics}
                    />
                  );
                })()
              )}
            </motion.div>
          )}

          {/* =========================================================================
              4) PORTFOLIO / WORK PAGE
             ========================================================================= */}
          {currentPage === 'work' && (
            <motion.div
              key="portfolio-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-5xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-12"
            >
              {/* Header */}
              <div className="flex flex-col gap-4 max-w-xl">
                <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-semibold">Client Case Studies</span>
                <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight">
                  Proving Our Work with Clear Outcomes
                </h1>
                <p className="text-sm text-zinc-400 font-light leading-relaxed">
                  Every project TechRooot accepts has clear milestones and measurable business results. Explore our dynamic case studies below.
                </p>
              </div>

              {/* INTERACTIVE BEFORE/AFTER SLIDER TOOL (Highly Requested!) */}
              <section id="interactive-before-after-tool" className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-8 pb-4 border-b border-zinc-800">
                  <div>
                    <span className="text-xs font-mono text-brand-accent uppercase tracking-wider block mb-1">Interactive Outcomes Selector</span>
                    <h3 className="font-display font-bold text-lg text-white">Evaluate Client Performance Shifts</h3>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {projects.map((proj) => (
                      <button
                        key={proj.id}
                        id={`before-after-selector-btn-${proj.id}`}
                        onClick={() => setActiveBeforeAfterId(proj.id)}
                        className={`px-3.5 py-2 text-xs font-mono rounded-xl border transition-all cursor-pointer ${
                          activeBeforeAfterId === proj.id
                            ? 'bg-brand-accent text-black font-semibold border-brand-accent shadow-[0_0_10px_rgba(245,158,11,0.2)]'
                            : 'bg-zinc-950 text-zinc-400 border-zinc-800/80 hover:text-white'
                        }`}
                      >
                        {proj.title}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Display comparison panel */}
                {(() => {
                  const p = projects.find(proj => proj.id === activeBeforeAfterId);
                  if (!p) return null;
                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center animate-fadeIn">
                      <div className="flex flex-col gap-4">
                        <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">{p.category} • {p.industry}</span>
                        <h4 className="font-display font-bold text-2xl text-white">{p.clientName}</h4>
                        <p className="text-xs text-zinc-400 font-light leading-relaxed">{p.summary}</p>
                        
                        <div className="grid grid-cols-2 gap-4 mt-4 bg-zinc-950 p-4 rounded-2xl border border-zinc-800">
                          <div>
                            <span className="text-[9px] font-mono text-red-400 uppercase tracking-wider block mb-1">{p.beforeLabel || 'Initial Baseline'}</span>
                            <span className="text-xl font-display font-bold text-white">{p.beforeValue || 'Standard'}</span>
                          </div>
                          <div>
                            <span className="text-[9px] font-mono text-emerald-400 uppercase tracking-wider block mb-1">{p.afterLabel || 'Growth Scale'}</span>
                            <span className="text-xl font-display font-bold text-brand-accent">{p.afterValue || 'Enhanced'}</span>
                          </div>
                        </div>

                        <button
                          onClick={() => handleNavigate('case-study', p.id)}
                          className="flex items-center gap-1 text-xs font-mono text-white hover:text-brand-accent transition-colors mt-2 self-start cursor-pointer"
                        >
                          Read full growth strategy →
                        </button>
                      </div>

                      <div className="relative rounded-2xl overflow-hidden border border-zinc-800 h-64 md:h-72">
                        <img src={p.imageUrl} alt="" className="w-full h-full object-cover opacity-80" />
                        
                        {/* Overlay result pill */}
                        <div className="absolute bottom-6 left-6 right-6 glass-panel border border-zinc-800 rounded-xl p-4 flex items-center justify-between">
                          <div>
                            <span className="text-[9px] font-mono text-brand-accent uppercase tracking-widest">Growth Lift</span>
                            <span className="block text-lg font-bold text-white">{p.results[0].value}</span>
                          </div>
                          <span className="text-xs text-zinc-400 font-mono font-light text-right">{p.results[0].metric} achieved</span>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </section>

              {/* Complete Case Studies Portfolio Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                {projects.map((proj) => (
                  <div
                    key={proj.id}
                    id={`portfolio-item-card-${proj.id}`}
                    onClick={() => handleNavigate('case-study', proj.id)}
                    className="group bg-zinc-900/30 hover:bg-zinc-900 border border-zinc-900 hover:border-zinc-800 rounded-3xl p-6 transition-all duration-300 cursor-pointer flex flex-col justify-between"
                  >
                    <div>
                      <div className="relative rounded-2xl overflow-hidden mb-6 border border-zinc-800/80 h-52">
                        <img
                          src={proj.imageUrl}
                          alt={proj.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <span className="absolute top-4 right-4 bg-zinc-950/85 backdrop-blur-sm border border-zinc-800 text-[10px] font-mono px-2.5 py-1 rounded-full text-brand-accent uppercase tracking-wider font-semibold">
                          {proj.timeline}
                        </span>
                      </div>

                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-mono text-brand-accent uppercase tracking-wider">{proj.category}</span>
                        <span className="text-xs text-zinc-500 font-mono">{proj.industry}</span>
                      </div>

                      <h3 className="font-display font-bold text-xl text-white mb-2 group-hover:text-brand-accent transition-colors">{proj.clientName}</h3>
                      <p className="text-xs text-zinc-400 font-light leading-relaxed mb-6">{proj.summary}</p>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-zinc-800/60">
                      <div>
                        <span className="text-[9px] font-mono text-zinc-500 block uppercase">Measurable success</span>
                        <span className="text-sm font-semibold text-white">{proj.results[0].value} {proj.results[0].metric}</span>
                      </div>
                      <span className="text-xs font-mono text-zinc-400 hover:text-white flex items-center gap-1">
                        Read Story <ArrowUpRight className="w-3.5 h-3.5 text-brand-accent" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>

            </motion.div>
          )}

          {/* =========================================================================
              5) CASE STUDY PAGE TEMPLATE (Dynamic view per project)
             ========================================================================= */}
          {currentPage === 'case-study' && (
            <motion.div
              key="case-study-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-4xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-12"
            >
              {(() => {
                const p = projects.find(proj => proj.id === selectedProjectId);
                if (!p) {
                  return (
                    <div className="text-center py-20">
                      <p className="text-zinc-400">Case Study not found.</p>
                      <button onClick={() => handleNavigate('work')} className="text-brand-accent text-sm font-mono mt-4">Return to work</button>
                    </div>
                  );
                }
                return (
                  <div className="flex flex-col gap-12">
                    {/* Header */}
                    <div>
                      <button
                        onClick={() => handleNavigate('work')}
                        className="text-xs font-mono text-zinc-500 hover:text-brand-accent mb-6 flex items-center gap-1 cursor-pointer"
                      >
                        ← Back to Work Portfolio
                      </button>
                      <span className="text-xs font-mono text-brand-accent uppercase tracking-widest block mb-2">{p.category} Case Study</span>
                      <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight leading-none mb-4">{p.clientName}</h1>
                      <p className="text-base text-zinc-400 font-light leading-relaxed max-w-xl">{p.summary}</p>
                    </div>

                    {/* Cover image & Metrics Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="md:col-span-2 rounded-3xl overflow-hidden border border-zinc-800 h-80">
                        <img src={p.imageUrl} alt="" className="w-full h-full object-cover" />
                      </div>

                      {/* Side Stats */}
                      <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-3xl flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block mb-4">Contract Metadata</span>
                          <div className="flex flex-col gap-4">
                            <div>
                              <span className="text-[9px] font-mono text-zinc-500 block uppercase">Timeline</span>
                              <span className="text-sm font-semibold text-white">{p.timeline}</span>
                            </div>
                            <div>
                              <span className="text-[9px] font-mono text-zinc-500 block uppercase">Target Market</span>
                              <span className="text-sm font-semibold text-white">{p.industry}</span>
                            </div>
                          </div>
                        </div>

                        <div className="pt-6 border-t border-zinc-800/80">
                          <span className="text-[9px] font-mono text-brand-accent block uppercase tracking-widest mb-1">Key Growth Metric</span>
                          <span className="text-2xl font-display font-bold text-white">{p.results[0].value}</span>
                          <span className="text-[10px] font-mono text-zinc-400 block mt-0.5">{p.results[0].metric} scale realization</span>
                        </div>
                      </div>
                    </div>

                    {/* Growth narrative report sections */}
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 border-t border-zinc-900 pt-10">
                      
                      {/* Left: Challenge and Strategy */}
                      <div className="lg:col-span-8 flex flex-col gap-8">
                        <div>
                          <h3 className="font-display font-bold text-xl text-white mb-3">The Challenge</h3>
                          <p className="text-sm text-zinc-300 font-light leading-relaxed">{p.challenge}</p>
                        </div>

                        <div>
                          <h3 className="font-display font-bold text-xl text-white mb-3">Our Growth Strategy</h3>
                          <p className="text-sm text-zinc-300 font-light leading-relaxed">{p.strategy}</p>
                        </div>
                      </div>

                      {/* Right: Deliverables List */}
                      <div className="lg:col-span-4 bg-zinc-900/20 p-6 rounded-2xl border border-zinc-900 h-fit">
                        <h4 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-widest mb-4">Division Deliverables</h4>
                        <ul className="flex flex-col gap-3 text-xs text-zinc-400 font-light">
                          {p.deliverables && p.deliverables.map((del) => (
                            <li key={del} className="flex gap-2 leading-relaxed">
                              <Check className="w-4 h-4 text-brand-accent shrink-0 mt-0.5" />
                              <span>{del}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Numeric Results Dashboard */}
                    <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-8">
                      <h3 className="font-display font-bold text-xl text-white mb-6 text-center">Measurable Scale Outcomes</h3>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                        {p.results.map((res) => (
                          <div key={res.metric} className="text-center p-4 bg-zinc-950 rounded-2xl border border-zinc-800/60">
                            <span className="block text-3xl font-display font-bold text-brand-accent">{res.value}</span>
                            <span className="block text-xs font-semibold text-white mt-2">{res.metric}</span>
                            <span className="block text-[10px] font-mono text-zinc-500 mt-1">{res.subtext}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Testimonial Quote */}
                    {p.testimonialText && (
                      <div className="glass-panel p-8 rounded-3xl border border-zinc-800 italic relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/3 rounded-full blur-2xl pointer-events-none" />
                        <p className="text-sm text-zinc-300 font-light leading-relaxed mb-4">
                          "{p.testimonialText}"
                        </p>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono text-white font-semibold">{p.testimonialAuthor}</span>
                          <span className="text-xs text-zinc-500 font-mono">• {p.testimonialRole}</span>
                        </div>
                      </div>
                    )}

                    {/* CTA section */}
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-6 p-8 bg-zinc-900 rounded-3xl border border-zinc-900 text-center sm:text-left">
                      <div>
                        <h4 className="font-display font-bold text-white text-lg">Interested in similar results for your business?</h4>
                        <p className="text-xs text-zinc-400 mt-1 font-light">Set up a secure discovery retainer or book an executive onboarding call today.</p>
                      </div>
                      <button
                        onClick={() => handleNavigate('contact')}
                        className="bg-brand-accent text-black font-semibold text-xs px-6 py-3.5 rounded-xl hover:shadow-[0_0_15px_rgba(245,158,11,0.25)] transition-all cursor-pointer whitespace-nowrap"
                      >
                        Launch project
                      </button>
                    </div>

                  </div>
                );
              })()}
            </motion.div>
          )}

          {/* =========================================================================
              6) CLIENTS PAGE
             ========================================================================= */}
          {currentPage === 'clients' && (
            <motion.div
              key="clients-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-5xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-12"
            >
              {/* Header */}
              <div className="flex flex-col gap-4 max-w-xl">
                <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-semibold">Our Partners</span>
                <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight leading-none">
                  The Client Database
                </h1>
                <p className="text-sm text-zinc-400 font-light leading-relaxed">
                  We maintain long-term partnerships with leading real-estate investors, executive founders, and service groups globally.
                </p>
              </div>

              {/* Clients database list */}
              <div className="grid grid-cols-1 gap-6">
                {clients.map((cli) => (
                  <div key={cli.id} className="bg-zinc-900/40 border border-zinc-900 p-6 sm:p-8 rounded-3xl flex flex-col gap-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-900 pb-4">
                      <div>
                        <h3 className="font-display font-bold text-xl text-white">{cli.name}</h3>
                        <p className="text-xs text-zinc-500 font-mono mt-0.5">{cli.industry} • {cli.timeline} retainer</p>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {cli.services.map((s) => (
                          <span key={s} className="bg-zinc-900 border border-zinc-800 text-[10px] font-mono px-2.5 py-1 rounded-full text-zinc-400">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-6 font-light">
                      <div className="md:col-span-8">
                        <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block mb-1">Partnership Summary</span>
                        <p className="text-xs text-zinc-300 leading-relaxed">{cli.summary}</p>
                      </div>

                      <div className="md:col-span-4 bg-zinc-900/80 p-4 rounded-xl border border-zinc-800/40">
                        <span className="text-[10px] font-mono text-brand-accent uppercase tracking-wider block mb-1">Scale outcomes</span>
                        <p className="text-xs text-white font-medium leading-relaxed">{cli.results}</p>
                      </div>
                    </div>

                    {cli.testimonial && (
                      <div className="bg-zinc-950 p-4 rounded-xl text-xs italic text-zinc-400 border border-zinc-800 leading-relaxed">
                        "{cli.testimonial}"
                      </div>
                    )}
                  </div>
                ))}
              </div>

            </motion.div>
          )}

          {/* =========================================================================
              7) INDUSTRIES PAGE
             ========================================================================= */}
          {currentPage === 'industries' && (
            <motion.div
              key="industries-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-5xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-12"
            >
              {/* Header */}
              <div className="flex flex-col gap-4 max-w-xl">
                <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-semibold">Sectors We Serve</span>
                <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight leading-none">
                  Sectors We Specialize In
                </h1>
                <p className="text-sm text-zinc-400 font-light leading-relaxed">
                  We design highly specific commercial workflows tailored to your sector constraints.
                </p>
              </div>

              {/* Sectors Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {INDUSTRIES.map((ind) => (
                  <div key={ind.id} className="bg-zinc-900/40 border border-zinc-900 hover:border-zinc-800/80 p-8 rounded-3xl flex flex-col justify-between gap-6">
                    <div>
                      <span className="text-xs font-mono text-brand-accent uppercase tracking-wider block mb-2">{ind.name}</span>
                      <p className="text-xs text-zinc-400 font-light leading-relaxed mb-6">{ind.description}</p>
                      
                      <div className="flex flex-col gap-3">
                        <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Active Solutions</span>
                        <ul className="grid grid-cols-2 gap-2 text-[11px] text-zinc-300 font-mono">
                          {ind.servicesProvided.map((s) => (
                            <li key={s} className="flex items-center gap-1">
                              <Check className="w-3 h-3 text-brand-accent shrink-0" />
                              <span>{s}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-zinc-900 flex items-center justify-between text-[11px] font-mono text-zinc-500">
                      <span>Vetted Clients:</span>
                      <span className="text-zinc-300 font-medium">{ind.clientHighlights[0]}</span>
                    </div>
                  </div>
                ))}
              </div>

            </motion.div>
          )}

          {/* =========================================================================
              8) TESTIMONIALS PAGE
             ========================================================================= */}
          {currentPage === 'testimonials' && (
            <motion.div
              key="testimonials-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-5xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-12"
            >
              {/* Header */}
              <div className="flex flex-col gap-4 max-w-xl">
                <span className="text-xs font-mono text-brand-accent uppercase tracking-widest">Verified Client Feedback</span>
                <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight leading-none">
                  The Star Wall of Proof
                </h1>
                <p className="text-sm text-zinc-400 font-light leading-relaxed">
                  We are incredibly proud of our verified Superhost feedback and B2B recommendation records.
                </p>
              </div>

              {/* Feed Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {testimonials.map((test) => (
                  <div key={test.id} className="bg-zinc-900/40 border border-zinc-900 p-6 sm:p-8 rounded-3xl flex flex-col justify-between gap-6 relative">
                    <div className="absolute top-6 right-6 font-mono text-[10px] text-zinc-600 uppercase border border-zinc-800 px-2.5 py-0.5 rounded-full bg-zinc-950">
                      {test.platform}
                    </div>

                    <div>
                      {/* Rating Stars */}
                      <div className="flex items-center gap-1 text-brand-accent mb-4">
                        {[...Array(test.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-brand-accent" />
                        ))}
                      </div>

                      <p className="text-xs text-zinc-300 font-light leading-relaxed italic">
                        "{test.text}"
                      </p>
                    </div>

                    <div className="flex items-center gap-3 pt-4 border-t border-zinc-900/80 mt-2">
                      <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center font-mono text-xs font-bold text-brand-accent uppercase">
                        {test.authorName.slice(0, 2)}
                      </div>
                      <div>
                        <h4 className="text-xs font-semibold text-white">{test.authorName}</h4>
                        <p className="text-[10px] text-zinc-500 font-mono">{test.role} • {test.company}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

            </motion.div>
          )}

          {/* =========================================================================
              9) BLOG / INSIGHTS PAGE (With full reading sub-view!)
             ========================================================================= */}
          {currentPage === 'blog' && (
            <motion.div
              key="blog-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-5xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-12"
            >
              {selectedBlogId === null ? (
                <>
                  {/* Articles index */}
                  <div className="flex flex-col gap-4 max-w-xl">
                    <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-semibold">Studio Insights</span>
                    <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight leading-none">
                      The Editorial Growth Journal
                    </h1>
                    <p className="text-sm text-zinc-400 font-light leading-relaxed">
                      Deep technical breakdowns covering hospitality, executive social marketing, custom code conversion, and back-office automations.
                    </p>
                  </div>

                  {/* Blogs Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                    {blogs.map((post) => (
                      <div
                        key={post.id}
                        onClick={() => setSelectedBlogId(post.id)}
                        className="group bg-zinc-900/40 hover:bg-zinc-900 border border-zinc-900 hover:border-zinc-800 p-6 rounded-3xl transition-all duration-300 cursor-pointer flex flex-col justify-between"
                      >
                        <div>
                          <div className="rounded-2xl overflow-hidden mb-6 border border-zinc-800 h-44">
                            <img src={post.imageUrl} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                          </div>

                          <div className="flex items-center justify-between mb-2">
                            <span className="text-[10px] font-mono text-brand-accent uppercase tracking-wider">{post.category}</span>
                            <span className="text-[10px] font-mono text-zinc-500">{post.readTime}</span>
                          </div>

                          <h3 className="font-display font-bold text-lg text-white mb-3 group-hover:text-brand-accent transition-colors">{post.title}</h3>
                          <p className="text-xs text-zinc-400 font-light leading-relaxed mb-6">{post.summary}</p>
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t border-zinc-800/50 mt-2 text-[10px] font-mono text-zinc-500">
                          <span>{post.publishedAt}</span>
                          <span className="text-zinc-400 group-hover:text-white transition-colors">Read article →</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                /* Dynamic Full Article Reading Sub-View */
                (() => {
                  const b = blogs.find(post => post.id === selectedBlogId);
                  if (!b) return null;
                  return (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="max-w-2xl mx-auto flex flex-col gap-8"
                    >
                      <div>
                        <button
                          onClick={() => setSelectedBlogId(null)}
                          className="text-xs font-mono text-zinc-500 hover:text-brand-accent mb-6 flex items-center gap-1 cursor-pointer"
                        >
                          ← Back to Insights Journal
                        </button>
                        <span className="text-xs font-mono text-brand-accent uppercase tracking-widest block mb-2">{b.category} • {b.readTime}</span>
                        <h1 className="font-display font-bold text-3xl sm:text-4xl text-white tracking-tight leading-tight">{b.title}</h1>
                        <p className="text-xs text-zinc-500 font-mono mt-3">Published {b.publishedAt} by {b.author}</p>
                      </div>

                      <div className="rounded-2xl overflow-hidden border border-zinc-800 h-64 sm:h-80">
                        <img src={b.imageUrl} alt="" className="w-full h-full object-cover" />
                      </div>

                      {/* Formatting contents into readable editorial format */}
                      <div className="text-zinc-300 font-light text-sm leading-relaxed whitespace-pre-line flex flex-col gap-6">
                        {b.content}
                      </div>

                      {/* Share / Return footer */}
                      <div className="pt-8 border-t border-zinc-900 text-center">
                        <button
                          onClick={() => setSelectedBlogId(null)}
                          className="text-xs font-mono text-zinc-400 hover:text-brand-accent transition-colors cursor-pointer"
                        >
                          ← Return to Insights index
                        </button>
                      </div>

                    </motion.div>
                  );
                })()
              )}
            </motion.div>
          )}

          {/* =========================================================================
              10) CONTACT PAGE (With Lead submission and Calendly Scheduler!)
             ========================================================================= */}
          {currentPage === 'contact' && (
            <motion.div
              key="contact-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-5xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-16"
            >
              {/* Header */}
              <div className="flex flex-col gap-4 max-w-xl">
                <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-semibold">Discovery Consultations</span>
                <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight leading-none">
                  Let's Discuss Growth Targets
                </h1>
                <p className="text-sm text-zinc-400 font-light leading-relaxed">
                  Submit your details below to file a lead submission directly in our database, or pick a direct consultation slot below.
                </p>
              </div>

              {/* Form & Calendar Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
                
                {/* Left Side: Lead submission form */}
                <div className="lg:col-span-6 bg-zinc-900 border border-zinc-900 p-8 rounded-3xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/3 rounded-full blur-2xl pointer-events-none" />
                  
                  <h3 className="font-display font-bold text-xl text-white mb-6">Submit Growth Brief</h3>

                  <form id="contact-lead-form" onSubmit={handleContactSubmit} className="flex flex-col gap-5">
                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="form-name-input" className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Your Full Name</label>
                      <input
                        type="text"
                        id="form-name-input"
                        required
                        className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-brand-accent transition-colors"
                        placeholder="e.g. Rebecca Alvarez"
                        value={formName}
                        onChange={(e) => setFormName(e.target.value)}
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="form-email-input" className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Your Business Email</label>
                      <input
                        type="email"
                        id="form-email-input"
                        required
                        className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-brand-accent transition-colors"
                        placeholder="rebecca@vistascapes.com"
                        value={formEmail}
                        onChange={(e) => setFormEmail(e.target.value)}
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="form-company-input" className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Company / Asset Name</label>
                      <input
                        type="text"
                        id="form-company-input"
                        className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-brand-accent transition-colors"
                        placeholder="e.g. VistaScapes Hospitality"
                        value={formCompany}
                        onChange={(e) => setFormCompany(e.target.value)}
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="form-service-selector" className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Growth offering targeted</label>
                      <select
                        id="form-service-selector"
                        className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-brand-accent transition-colors"
                        value={formService}
                        onChange={(e) => setFormService(e.target.value)}
                      >
                        <option value="Website Development">Website Development</option>
                        <option value="Airbnb & Hospitality Management">Airbnb & Hospitality Management</option>
                        <option value="LinkedIn Executive Management">LinkedIn Executive Management</option>
                        <option value="AI Automation & Custom Workflows">AI Automation & Custom Workflows</option>
                        <option value="Branding & Visual Identity">Branding & Visual Identity</option>
                        <option value="Performance Marketing (Ads)">Performance Marketing (Ads)</option>
                      </select>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="form-message-input" className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Growth targets or project parameters</label>
                      <textarea
                        id="form-message-input"
                        required
                        rows={3}
                        className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-brand-accent transition-colors"
                        placeholder="Briefly share occupancy challenges, website conversion speed goals, or automated back-office bottlenecks..."
                        value={formMessage}
                        onChange={(e) => setFormMessage(e.target.value)}
                      />
                    </div>

                    {contactSuccess && (
                      <div className="p-3 bg-emerald-950/20 border border-emerald-900/50 text-emerald-400 text-xs rounded-xl flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>Brief submitted successfully! This lead has instantly entered our live Admin Portal.</span>
                      </div>
                    )}

                    <button
                      type="submit"
                      id="form-lead-submit-btn"
                      className="w-full flex items-center justify-center gap-2 bg-brand-accent text-black font-semibold py-3.5 rounded-xl hover:shadow-[0_0_15px_rgba(245,158,11,0.2)] transition-all cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      Submit Growth Brief
                    </button>
                  </form>
                </div>

                {/* Right Side: Mock Calendly Consultation Booking */}
                <div className="lg:col-span-6 bg-zinc-900 border border-zinc-900 p-8 rounded-3xl flex flex-col gap-6">
                  <div>
                    <h3 className="font-display font-bold text-xl text-white mb-2">Book Strategic Onboarding</h3>
                    <p className="text-xs text-zinc-400 font-light leading-relaxed">
                      Select an available day and hour slot below to queue a simulated consultation appointment directly in our leads database.
                    </p>
                  </div>

                  <form id="contact-booking-form" onSubmit={handleBookingSubmit} className="flex flex-col gap-4">
                    {/* Date Selector */}
                    <div className="flex flex-col gap-2">
                      <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Select Available Day</span>
                      <div className="grid grid-cols-3 gap-2">
                        {['2026-06-30', '2026-07-01', '2026-07-02'].map((d) => (
                          <button
                            key={d}
                            type="button"
                            id={`booking-date-btn-${d}`}
                            onClick={() => setSelectedDate(d)}
                            className={`py-3 text-xs font-mono rounded-xl border text-center transition-all cursor-pointer ${
                              selectedDate === d
                                ? 'bg-brand-accent text-black font-semibold border-brand-accent'
                                : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
                            }`}
                          >
                            {new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Time Selector */}
                    <div className="flex flex-col gap-2">
                      <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Select Time (UTC-7)</span>
                      <div className="grid grid-cols-2 gap-2">
                        {['10:00 AM', '02:30 PM', '04:00 PM'].map((t) => (
                          <button
                            key={t}
                            type="button"
                            id={`booking-time-btn-${t}`}
                            onClick={() => setSelectedTime(t)}
                            className={`py-3 text-xs font-mono rounded-xl border text-center transition-all cursor-pointer ${
                              selectedTime === t
                                ? 'bg-brand-accent text-black font-semibold border-brand-accent'
                                : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
                            }`}
                          >
                            {t}
                          </button>
                        ))}
                      </div>
                    </div>

                    {bookingSuccess && (
                      <div className="p-3 bg-emerald-950/20 border border-emerald-900/50 text-emerald-400 text-xs rounded-xl flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>Meeting Confirmed! Dynamic reservation logged in your administrative reports.</span>
                      </div>
                    )}

                    <button
                      type="submit"
                      id="form-booking-submit-btn"
                      disabled={!selectedDate || !selectedTime}
                      className="w-full flex items-center justify-center gap-2 bg-zinc-950 hover:bg-zinc-850 border border-zinc-800 hover:border-zinc-700 text-white font-medium py-3.5 rounded-xl transition-all cursor-pointer disabled:opacity-40"
                    >
                      <Calendar className="w-4 h-4 text-brand-accent" />
                      Lock Appointment Time
                    </button>
                  </form>

                  {/* Direct Contact Options */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-zinc-900 pt-6 font-mono text-xs text-zinc-500">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-brand-accent" />
                      <span>grow@techrooot.studio</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-brand-accent" />
                      <span>WhatsApp Simulated Call</span>
                    </div>
                  </div>
                </div>

              </div>
            </motion.div>
          )}

          {/* =========================================================================
              11) CAREERS PAGE
             ========================================================================= */}
          {currentPage === 'careers' && (
            <motion.div
              key="careers-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="max-w-5xl mx-auto px-6 pt-32 pb-20 flex flex-col gap-12"
            >
              {/* Header */}
              <div className="flex flex-col gap-4 max-w-xl">
                <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-semibold">Join the Studio</span>
                <h1 className="font-display font-bold text-4xl sm:text-5xl text-white tracking-tight leading-none">
                  Build the Future of Creative Growth
                </h1>
                <p className="text-sm text-zinc-400 font-light leading-relaxed">
                  We look for exceptional, highly independent, technical creatives who value pristine craftsmanship and mathematical execution.
                </p>
              </div>

              {/* Cultural Principles */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-zinc-900/40 p-6 rounded-2xl border border-zinc-900">
                  <span className="font-display font-bold text-white text-base">Creator-In-Residence Retainers</span>
                  <p className="text-xs text-zinc-400 font-light mt-2 leading-relaxed">
                    We partner with niche freelance copywriters and staging directors on flexible, high-yield retainer bases. Learn directly from luxury B2B operations.
                  </p>
                </div>
                <div className="bg-zinc-900/40 p-6 rounded-2xl border border-zinc-900">
                  <span className="font-display font-bold text-white text-base">Elite Full-Stack Internships</span>
                  <p className="text-xs text-zinc-400 font-light mt-2 leading-relaxed">
                    Gain direct exposure to high-converting product builds, automated API configurations, and local advertising analytics. We run flat operational networks.
                  </p>
                </div>
              </div>

              {/* Application Form Sim */}
              <div className="bg-zinc-900 border border-zinc-900 p-8 rounded-3xl max-w-2xl mx-auto w-full relative">
                <h3 className="font-display font-bold text-xl text-white mb-6 text-center">Collaborator Intake Form</h3>
                
                <form
                  id="careers-application-form"
                  onSubmit={(e) => {
                    e.preventDefault();
                    alert('Intake brief submitted! Check leads manager in administrator panel.');
                    handleNavigate('home');
                  }}
                  className="flex flex-col gap-5"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-mono text-zinc-500 uppercase">Your Name</label>
                      <input type="text" required className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white" placeholder="Arpan G." />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-mono text-zinc-500 uppercase">Role targeted</label>
                      <select className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white">
                        <option>B2B Copywriter & DM Triage</option>
                        <option>Full-Stack React Engineer</option>
                        <option>AI Automation Designer</option>
                        <option>Interior Staging Consultant</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-mono text-zinc-500 uppercase">Portfolio or LinkedIn URL</label>
                    <input type="url" required className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white" placeholder="https://linkedin.com/in/username" />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-mono text-zinc-500 uppercase">Tell us about an outstanding project you built</label>
                    <textarea rows={3} required className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white" placeholder="Share core metric outcomes or custom engineering milestones achieved..." />
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 bg-brand-accent text-black font-semibold py-3.5 rounded-xl hover:shadow-[0_0_15px_rgba(245,158,11,0.2)] transition-all cursor-pointer"
                  >
                    Submit Intake Application
                  </button>
                </form>
              </div>

            </motion.div>
          )}

          {/* =========================================================================
              12) ADMINISTRATOR WORKSPACE / PORTAL SCREEN
             ========================================================================= */}
          {currentPage === 'admin' && (
            <motion.div
              key="admin-workspace-page"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <AdminPortal
                projects={projects}
                setProjects={setProjects}
                clients={clients}
                setClients={setClients}
                services={services}
                setServices={setServices}
                blogs={blogs}
                setBlogs={setBlogs}
                testimonials={testimonials}
                setTestimonials={setTestimonials}
                leads={leads}
                setLeads={setLeads}
                subscriptions={subscriptions}
                setSubscriptions={setSubscriptions}
                analytics={analytics}
                setAnalytics={setAnalytics}
                isAdminLoggedIn={isAdminLoggedIn}
                onLoginSuccess={handleAdminLoginSuccess}
                onLogout={handleAdminLogout}
              />
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Global Interactive Stripe Checkout Modal Portal */}
      <StripeCheckout
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        onSubscriptionCreated={handleSubscriptionCreated}
      />

      {/* Global Footer Layout */}
      {currentPage !== 'admin' && (
        <Footer
          onNavigate={handleNavigate}
          isAdminLoggedIn={isAdminLoggedIn}
        />
      )}

    </div>
  );
}
