/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area
} from 'recharts';
import {
  Shield, Key, LayoutDashboard, Database, Inbox, CreditCard, LogOut,
  TrendingUp, Users, Clock, AlertCircle, Plus, Edit, Trash2, CheckCircle2,
  Bookmark, Send, RefreshCw, Layers, Check, X, FileText, Briefcase
} from 'lucide-react';
import { Project, Client, Service, BlogPost, Testimonial, Lead, StripeSubscription, AnalyticsStats } from '../types';
import { saveCMSData } from '../data/cmsData';

interface AdminPortalProps {
  projects: Project[];
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  clients: Client[];
  setClients: React.Dispatch<React.SetStateAction<Client[]>>;
  services: Service[];
  setServices: React.Dispatch<React.SetStateAction<Service[]>>;
  blogs: BlogPost[];
  setBlogs: React.Dispatch<React.SetStateAction<BlogPost[]>>;
  testimonials: Testimonial[];
  setTestimonials: React.Dispatch<React.SetStateAction<Testimonial[]>>;
  leads: Lead[];
  setLeads: React.Dispatch<React.SetStateAction<Lead[]>>;
  subscriptions: StripeSubscription[];
  setSubscriptions: React.Dispatch<React.SetStateAction<StripeSubscription[]>>;
  analytics: AnalyticsStats;
  setAnalytics: React.Dispatch<React.SetStateAction<AnalyticsStats>>;
  isAdminLoggedIn: boolean;
  onLoginSuccess: () => void;
  onLogout: () => void;
}

const COLORS = ['#A3E635', '#3b82f6', '#10b981', '#a855f7', '#ec4899'];

export default function AdminPortal({
  projects, setProjects,
  clients, setClients,
  services, setServices,
  blogs, setBlogs,
  testimonials, setTestimonials,
  leads, setLeads,
  subscriptions, setSubscriptions,
  analytics, setAnalytics,
  isAdminLoggedIn,
  onLoginSuccess,
  onLogout
}: AdminPortalProps) {
  // Login states
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Active tab
  const [activeTab, setActiveTab] = useState<'dashboard' | 'cms' | 'leads' | 'billing'>('dashboard');
  
  // CMS sub-tab
  const [cmsTab, setCmsTab] = useState<'projects' | 'clients' | 'blogs' | 'testimonials'>('projects');

  // Modal / Editor states
  const [editingItem, setEditingItem] = useState<any>(null);
  const [editorType, setEditorType] = useState<'project' | 'client' | 'blog' | 'testimonial' | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);

  // Stats summary calculation
  const totalInboundRevenue = subscriptions
    .filter(s => s.status === 'active')
    .reduce((acc, curr) => acc + (curr.interval === 'monthly' ? curr.amount : Math.round(curr.amount / 12)), 0);

  useEffect(() => {
    // Update local state and sync revenue back to analytics
    setAnalytics(prev => ({
      ...prev,
      monthlyRevenue: totalInboundRevenue,
      activeSubscriptions: subscriptions.filter(s => s.status === 'active').length
    }));
  }, [subscriptions, totalInboundRevenue, setAnalytics]);

  // Handle Authentication
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.toLowerCase() === 'admin' && password === 'admin123') {
      onLoginSuccess();
      setLoginError('');
    } else {
      setLoginError('Invalid Administrator credentials. Please verify your credentials.');
    }
  };

  // Status updates
  const updateLeadStatus = (leadId: string, status: Lead['status']) => {
    const updated = leads.map(l => l.id === leadId ? { ...l, status } : l);
    setLeads(updated);
    saveCMSData('leads', updated);
  };

  const toggleSubscriptionStatus = (subId: string) => {
    const updated = subscriptions.map(s => {
      if (s.id === subId) {
        return {
          ...s,
          status: s.status === 'active' ? 'canceled' as const : 'active' as const
        };
      }
      return s;
    });
    setSubscriptions(updated);
    saveCMSData('subscriptions', updated);
  };

  // CMS deletion
  const handleDeleteItem = (id: string, type: 'project' | 'client' | 'blog' | 'testimonial') => {
    if (!window.confirm('Are you sure you want to delete this content item?')) return;

    if (type === 'project') {
      const filtered = projects.filter(p => p.id !== id);
      setProjects(filtered);
      saveCMSData('projects', filtered);
    } else if (type === 'client') {
      const filtered = clients.filter(c => c.id !== id);
      setClients(filtered);
      saveCMSData('clients', filtered);
    } else if (type === 'blog') {
      const filtered = blogs.filter(b => b.id !== id);
      setBlogs(filtered);
      saveCMSData('blogs', filtered);
    } else if (type === 'testimonial') {
      const filtered = testimonials.filter(t => t.id !== id);
      setTestimonials(filtered);
      saveCMSData('testimonials', filtered);
    }
  };

  // CMS saving
  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    if (editorType === 'project') {
      if (isAddingNew) {
        const withId = { ...editingItem, id: editingItem.id || `proj-${Date.now()}` };
        const updated = [...projects, withId];
        setProjects(updated);
        saveCMSData('projects', updated);
      } else {
        const updated = projects.map(p => p.id === editingItem.id ? editingItem : p);
        setProjects(updated);
        saveCMSData('projects', updated);
      }
    } else if (editorType === 'client') {
      if (isAddingNew) {
        const withId = { ...editingItem, id: editingItem.id || `cli-${Date.now()}` };
        const updated = [...clients, withId];
        setClients(updated);
        saveCMSData('clients', updated);
      } else {
        const updated = clients.map(c => c.id === editingItem.id ? editingItem : c);
        setClients(updated);
        saveCMSData('clients', updated);
      }
    } else if (editorType === 'blog') {
      if (isAddingNew) {
        const withId = { 
          ...editingItem, 
          id: editingItem.id || `blog-${Date.now()}`,
          publishedAt: editingItem.publishedAt || new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
        };
        const updated = [...blogs, withId];
        setBlogs(updated);
        saveCMSData('blogs', updated);
      } else {
        const updated = blogs.map(b => b.id === editingItem.id ? editingItem : b);
        setBlogs(updated);
        saveCMSData('blogs', updated);
      }
    } else if (editorType === 'testimonial') {
      if (isAddingNew) {
        const withId = { ...editingItem, id: editingItem.id || `test-${Date.now()}` };
        const updated = [...testimonials, withId];
        setTestimonials(updated);
        saveCMSData('testimonials', updated);
      } else {
        const updated = testimonials.map(t => t.id === editingItem.id ? editingItem : t);
        setTestimonials(updated);
        saveCMSData('testimonials', updated);
      }
    }

    // Reset editor
    setEditingItem(null);
    setEditorType(null);
    setIsAddingNew(false);
  };

  const openEditor = (item: any, type: 'project' | 'client' | 'blog' | 'testimonial', isNew = false) => {
    setIsAddingNew(isNew);
    setEditorType(type);
    
    if (isNew) {
      if (type === 'project') {
        setEditingItem({
          id: '',
          title: '',
          clientName: '',
          category: 'Web Development',
          industry: 'Technology',
          summary: '',
          challenge: '',
          strategy: '',
          deliverables: [],
          timeline: '1 Month',
          imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=600',
          content: '',
          results: [
            { metric: 'Inbound Growth', value: '150%', subtext: 'Scale lift realized' }
          ]
        });
      } else if (type === 'client') {
        setEditingItem({
          id: '',
          name: '',
          industry: '',
          services: [],
          summary: '',
          timeline: '3 Months',
          results: '',
          testimonial: ''
        });
      } else if (type === 'blog') {
        setEditingItem({
          id: '',
          title: '',
          category: 'Technology',
          author: 'TechRooot Writer',
          readTime: '5 min read',
          summary: '',
          content: '',
          imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=600'
        });
      } else if (type === 'testimonial') {
        setEditingItem({
          id: '',
          authorName: '',
          role: '',
          company: '',
          text: '',
          rating: 5,
          platform: 'Direct'
        });
      }
    } else {
      setEditingItem(JSON.parse(JSON.stringify(item))); // Deep clone to avoid mutating live data prior to save
    }
  };

  if (!isAdminLoggedIn) {
    return (
      <section id="admin-login-screen" className="min-h-screen pt-32 pb-20 flex items-center justify-center bg-zinc-950 px-6">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(245,158,11,0.03),transparent)] pointer-events-none" />
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md glass-panel p-8 rounded-3xl border border-zinc-800 relative overflow-hidden"
        >
          {/* Accent light decoration */}
          <div className="absolute -top-12 -right-12 w-24 h-24 bg-brand-accent/10 rounded-full blur-2xl" />

          <div className="flex flex-col items-center gap-3 mb-8 text-center">
            <div className="w-12 h-12 rounded-2xl bg-brand-accent/5 border border-brand-accent/20 flex items-center justify-center text-brand-accent">
              <Shield className="w-6 h-6 animate-pulse" />
            </div>
            <h1 className="font-display font-semibold text-2xl text-white tracking-tight">TechRooot Control</h1>
            <p className="text-sm text-zinc-400 font-light">
              Secure administrator panel to manage live CMS and evaluate visitor analytics.
            </p>
          </div>

          <form id="admin-login-form" onSubmit={handleLoginSubmit} className="flex flex-col gap-5">
            <div className="flex flex-col gap-2">
              <label htmlFor="admin-username-input" className="text-xs font-mono text-zinc-500 uppercase tracking-wider">Username</label>
              <div className="relative">
                <input
                  type="text"
                  id="admin-username-input"
                  className="w-full bg-zinc-900/50 border border-zinc-800 rounded-xl px-4 py-3.5 text-sm text-white focus:outline-none focus:border-brand-accent transition-colors"
                  placeholder="admin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <label htmlFor="admin-password-input" className="text-xs font-mono text-zinc-500 uppercase tracking-wider">Security Password</label>
              <div className="relative">
                <input
                  type="password"
                  id="admin-password-input"
                  className="w-full bg-zinc-900/50 border border-zinc-800 rounded-xl px-4 py-3.5 text-sm text-white focus:outline-none focus:border-brand-accent transition-colors"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            {loginError && (
              <div className="p-3 bg-red-950/20 border border-red-900/50 text-red-400 text-xs rounded-xl flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{loginError}</span>
              </div>
            )}

            <button
              type="submit"
              id="admin-login-submit"
              className="w-full flex items-center justify-center gap-2 bg-brand-accent text-black font-semibold py-4 rounded-xl hover:shadow-[0_0_20px_rgba(245,158,11,0.3)] transition-all mt-2 cursor-pointer"
            >
              <Key className="w-4 h-4" />
              Sign in to Dashboard
            </button>
          </form>

          {/* Quick instructions so testers can easily log in! */}
          <div className="mt-6 pt-6 border-t border-zinc-900 text-center">
            <span className="text-xs text-zinc-500 font-mono">
              Demo Access: <span className="text-brand-accent">admin</span> / <span className="text-brand-accent">admin123</span>
            </span>
          </div>
        </motion.div>
      </section>
    );
  }

  return (
    <section id="admin-portal-dashboard" className="min-h-screen pt-28 pb-20 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Portal Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-zinc-900 mb-8">
          <div>
            <div className="flex items-center gap-2 text-brand-accent mb-2">
              <Shield className="w-4 h-4" />
              <span className="text-xs font-mono tracking-widest uppercase">TechRooot Control Room</span>
            </div>
            <h1 className="font-display font-semibold text-3xl text-white tracking-tight">Studio Operations</h1>
          </div>
          
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-full text-zinc-400">
              Role: <span className="text-white font-medium">Administrator</span>
            </span>
            <button
              id="admin-logout-action-btn"
              onClick={onLogout}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-white transition-all cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5 text-zinc-400" />
              Exit Portal
            </button>
          </div>
        </div>

        {/* Portal Tabs Bar */}
        <div className="flex items-center gap-2 border-b border-zinc-900 pb-px mb-8 overflow-x-auto scrollbar-none">
          <button
            id="admin-tab-btn-dashboard"
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'border-brand-accent text-brand-accent'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            Analytics reports
          </button>
          
          <button
            id="admin-tab-btn-cms"
            onClick={() => setActiveTab('cms')}
            className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'cms'
                ? 'border-brand-accent text-brand-accent'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <Database className="w-4 h-4" />
            CMS Content Collections
          </button>

          <button
            id="admin-tab-btn-leads"
            onClick={() => setActiveTab('leads')}
            className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'leads'
                ? 'border-brand-accent text-brand-accent'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <Inbox className="w-4 h-4" />
            Leads & Inquiries
            {leads.filter(l => l.status === 'New').length > 0 && (
              <span className="bg-brand-accent text-black font-bold text-[10px] px-1.5 py-0.5 rounded-full">
                {leads.filter(l => l.status === 'New').length}
              </span>
            )}
          </button>

          <button
            id="admin-tab-btn-billing"
            onClick={() => setActiveTab('billing')}
            className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'billing'
                ? 'border-brand-accent text-brand-accent'
                : 'border-transparent text-zinc-400 hover:text-white'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            Stripe Payments
          </button>
        </div>

        {/* TAB 1: ANALYTICS DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="flex flex-col gap-8 animate-fadeIn">
            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl relative overflow-hidden">
                <div className="text-zinc-500 font-mono text-xs uppercase tracking-wider mb-2 flex items-center justify-between">
                  Monthly Revenue
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                </div>
                <div className="text-3xl font-display font-semibold text-white tracking-tight">
                  ${analytics.monthlyRevenue.toLocaleString()}<span className="text-xs text-zinc-400 font-light">/mo</span>
                </div>
                <div className="text-xs text-emerald-500 mt-2 font-light flex items-center gap-1">
                  <span>+18.5%</span> <span className="text-zinc-500">from last month</span>
                </div>
                <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
              </div>

              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl relative overflow-hidden">
                <div className="text-zinc-500 font-mono text-xs uppercase tracking-wider mb-2 flex items-center justify-between">
                  Active Subscriptions
                  <Users className="w-3.5 h-3.5 text-brand-accent" />
                </div>
                <div className="text-3xl font-display font-semibold text-white tracking-tight">
                  {analytics.activeSubscriptions}
                </div>
                <div className="text-xs text-brand-accent mt-2 font-light flex items-center gap-1">
                  <span>Stripe Billing</span> <span className="text-zinc-500">active accounts</span>
                </div>
                <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />
              </div>

              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl relative overflow-hidden">
                <div className="text-zinc-500 font-mono text-xs uppercase tracking-wider mb-2 flex items-center justify-between">
                  Traffic (Visitors)
                  <TrendingUp className="w-3.5 h-3.5 text-blue-500" />
                </div>
                <div className="text-3xl font-display font-semibold text-white tracking-tight">
                  {analytics.visitors.toLocaleString()}
                </div>
                <div className="text-xs text-blue-400 mt-2 font-light flex items-center gap-1">
                  <span>+24.2%</span> <span className="text-zinc-500">unique sessions</span>
                </div>
                <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-2xl pointer-events-none" />
              </div>

              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl relative overflow-hidden">
                <div className="text-zinc-500 font-mono text-xs uppercase tracking-wider mb-2 flex items-center justify-between">
                  Inbound Leads
                  <Inbox className="w-3.5 h-3.5 text-purple-500" />
                </div>
                <div className="text-3xl font-display font-semibold text-white tracking-tight">
                  {analytics.totalLeads + leads.length}
                </div>
                <div className="text-xs text-purple-400 mt-2 font-light flex items-center gap-1">
                  <span>{leads.length} new inbox</span> <span className="text-zinc-500">pipeline submissions</span>
                </div>
                <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />
              </div>
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Left Chart: Weekly Visitors */}
              <div className="lg:col-span-2 bg-zinc-900 border border-zinc-800 p-6 rounded-2xl">
                <h3 className="text-sm font-mono font-medium text-zinc-400 mb-6">Traffic & Engagement Session Volume</h3>
                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={analytics.visitorsHistory}>
                      <defs>
                        <linearGradient id="colorVisitors" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#A3E635" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#A3E635" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="day" stroke="#52525b" fontSize={11} tickLine={false} />
                      <YAxis stroke="#52525b" fontSize={11} tickLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                      <Area type="monotone" dataKey="count" stroke="#A3E635" strokeWidth={2} fillOpacity={1} fill="url(#colorVisitors)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Right Chart: Services Volume Breakdown */}
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-mono font-medium text-zinc-400 mb-4">Volume Booked By Service</h3>
                  <div className="h-48 w-full flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={analytics.servicesBreakdown}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {analytics.servicesBreakdown.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="flex flex-col gap-2 pt-4 border-t border-zinc-800/50">
                  {analytics.servicesBreakdown.map((item, idx) => (
                    <div key={item.name} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                        <span className="text-zinc-400">{item.name}</span>
                      </div>
                      <span className="font-mono text-white font-medium">{item.value}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Lower Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Lead Generations History */}
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl">
                <h3 className="text-sm font-mono font-medium text-zinc-400 mb-6">Inbound Lead Generation Trend</h3>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.leadsHistory}>
                      <XAxis dataKey="month" stroke="#52525b" fontSize={11} tickLine={false} />
                      <YAxis stroke="#52525b" fontSize={11} tickLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                      <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Traffic Channels Breakdown */}
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-mono font-medium text-zinc-400 mb-4">Traffic Acquisition Channels</h3>
                  <div className="h-44 w-full flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={analytics.trafficSources}
                          cx="50%"
                          cy="50%"
                          outerRadius={70}
                          labelLine={false}
                          dataKey="value"
                        >
                          {analytics.trafficSources.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[(index + 2) % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-4 border-t border-zinc-800/50">
                  {analytics.trafficSources.map((item, idx) => (
                    <div key={item.name} className="flex items-center gap-2 text-xs">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[(idx + 2) % COLORS.length] }} />
                      <span className="text-zinc-400">{item.name}:</span>
                      <span className="font-mono text-white font-medium ml-auto">{item.value}%</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB 2: CMS WORKSPACE */}
        {activeTab === 'cms' && (
          <div className="flex flex-col gap-8 animate-fadeIn">
            {/* CMS Sub-Selector */}
            <div className="flex items-center gap-2 bg-zinc-900/50 p-1 rounded-xl border border-zinc-900 max-w-xl">
              <button
                id="cms-subtab-btn-projects"
                onClick={() => setCmsTab('projects')}
                className={`flex-1 py-2 text-xs font-mono font-semibold rounded-lg transition-all cursor-pointer ${
                  cmsTab === 'projects' ? 'bg-zinc-800 text-brand-accent border border-zinc-700' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Projects (Case Studies)
              </button>
              <button
                id="cms-subtab-btn-clients"
                onClick={() => setCmsTab('clients')}
                className={`flex-1 py-2 text-xs font-mono font-semibold rounded-lg transition-all cursor-pointer ${
                  cmsTab === 'clients' ? 'bg-zinc-800 text-brand-accent border border-zinc-700' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Clients
              </button>
              <button
                id="cms-subtab-btn-blogs"
                onClick={() => setCmsTab('blogs')}
                className={`flex-1 py-2 text-xs font-mono font-semibold rounded-lg transition-all cursor-pointer ${
                  cmsTab === 'blogs' ? 'bg-zinc-800 text-brand-accent border border-zinc-700' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Insights (Blogs)
              </button>
              <button
                id="cms-subtab-btn-testimonials"
                onClick={() => setCmsTab('testimonials')}
                className={`flex-1 py-2 text-xs font-mono font-semibold rounded-lg transition-all cursor-pointer ${
                  cmsTab === 'testimonials' ? 'bg-zinc-800 text-brand-accent border border-zinc-700' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Testimonials
              </button>
            </div>

            {/* CMS Actions bar */}
            <div className="flex items-center justify-between pb-4 border-b border-zinc-900">
              <span className="text-xs font-mono text-zinc-500">
                Live Directory: <span className="text-white font-medium uppercase">{cmsTab} ({
                  cmsTab === 'projects' ? projects.length :
                  cmsTab === 'clients' ? clients.length :
                  cmsTab === 'blogs' ? blogs.length :
                  testimonials.length
                })</span>
              </span>

              <button
                id="cms-add-new-item-btn"
                onClick={() => openEditor(null, cmsTab.slice(0, -1) as any, true)}
                className="flex items-center gap-1.5 bg-brand-accent text-black font-semibold text-xs px-4 py-2.5 rounded-xl hover:shadow-[0_0_15px_rgba(245,158,11,0.2)] transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add New {cmsTab.slice(0, -1).toUpperCase()}
              </button>
            </div>

            {/* Editor form (Drawer overlay when editingItem is active) */}
            {editingItem && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-6 overflow-y-auto">
                <motion.div
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="bg-zinc-900 border border-zinc-800 rounded-3xl p-8 w-full max-w-2xl max-h-[85vh] overflow-y-auto relative"
                >
                  <button
                    onClick={() => { setEditingItem(null); setEditorType(null); }}
                    className="absolute top-6 right-6 p-2 rounded-full bg-zinc-950 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-all cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  <h3 className="font-display font-semibold text-xl text-white mb-6 flex items-center gap-2">
                    <Edit className="w-5 h-5 text-brand-accent" />
                    {isAddingNew ? 'Create New' : 'Modify Existing'} {editorType?.toUpperCase()}
                  </h3>

                  <form onSubmit={handleSaveItem} className="flex flex-col gap-5">
                    
                    {/* Common Field: ID (Only editable if adding new) */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-mono text-zinc-500 uppercase">Slug Identifier (Unique ID)</label>
                      <input
                        type="text"
                        className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-accent"
                        placeholder="e.g. nomad-nest"
                        value={editingItem.id}
                        onChange={(e) => setEditingItem({ ...editingItem, id: e.target.value.toLowerCase().replace(/\s+/g, '-') })}
                        disabled={!isAddingNew}
                        required
                      />
                    </div>

                    {/* PROJECT CMS FIELDS */}
                    {editorType === 'project' && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Project Title</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none"
                              value={editingItem.title}
                              onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                              required
                            />
                          </div>
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Client Name</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none"
                              value={editingItem.clientName}
                              onChange={(e) => setEditingItem({ ...editingItem, clientName: e.target.value })}
                              required
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Category Tag</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none"
                              placeholder="e.g. Airbnb Management"
                              value={editingItem.category}
                              onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                              required
                            />
                          </div>
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Industry</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none"
                              value={editingItem.industry}
                              onChange={(e) => setEditingItem({ ...editingItem, industry: e.target.value })}
                              required
                            />
                          </div>
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Image URL (Cover)</label>
                          <input
                            type="text"
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none"
                            value={editingItem.imageUrl}
                            onChange={(e) => setEditingItem({ ...editingItem, imageUrl: e.target.value })}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Brief Summary</label>
                          <textarea
                            rows={2}
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none"
                            value={editingItem.summary}
                            onChange={(e) => setEditingItem({ ...editingItem, summary: e.target.value })}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Challenge Statement</label>
                          <textarea
                            rows={3}
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none"
                            value={editingItem.challenge}
                            onChange={(e) => setEditingItem({ ...editingItem, challenge: e.target.value })}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Strategic Growth Execution</label>
                          <textarea
                            rows={3}
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none"
                            value={editingItem.strategy}
                            onChange={(e) => setEditingItem({ ...editingItem, strategy: e.target.value })}
                            required
                          />
                        </div>
                      </>
                    )}

                    {/* CLIENT CMS FIELDS */}
                    {editorType === 'client' && (
                      <>
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Client Organization Name</label>
                          <input
                            type="text"
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                            value={editingItem.name}
                            onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })}
                            required
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Industry</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                              value={editingItem.industry}
                              onChange={(e) => setEditingItem({ ...editingItem, industry: e.target.value })}
                              required
                            />
                          </div>
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Partnership Timeline</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                              value={editingItem.timeline}
                              onChange={(e) => setEditingItem({ ...editingItem, timeline: e.target.value })}
                              required
                            />
                          </div>
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Measurable Outcomes</label>
                          <input
                            type="text"
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                            placeholder="e.g. Scaled occupancy to 94%, added +$185 daily rate yields"
                            value={editingItem.results}
                            onChange={(e) => setEditingItem({ ...editingItem, results: e.target.value })}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Client Overview Description</label>
                          <textarea
                            rows={3}
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                            value={editingItem.summary}
                            onChange={(e) => setEditingItem({ ...editingItem, summary: e.target.value })}
                            required
                          />
                        </div>
                      </>
                    )}

                    {/* BLOG INSIGHTS CMS FIELDS */}
                    {editorType === 'blog' && (
                      <>
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Insight Title</label>
                          <input
                            type="text"
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                            value={editingItem.title}
                            onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                            required
                          />
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Category Tag</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                              value={editingItem.category}
                              onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                              required
                            />
                          </div>
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Author Name</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                              value={editingItem.author}
                              onChange={(e) => setEditingItem({ ...editingItem, author: e.target.value })}
                              required
                            />
                          </div>
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Reading Time</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                              placeholder="e.g. 5 min read"
                              value={editingItem.readTime}
                              onChange={(e) => setEditingItem({ ...editingItem, readTime: e.target.value })}
                              required
                            />
                          </div>
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Editorial Image URL</label>
                          <input
                            type="text"
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                            value={editingItem.imageUrl}
                            onChange={(e) => setEditingItem({ ...editingItem, imageUrl: e.target.value })}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Abstract / Summary</label>
                          <textarea
                            rows={2}
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                            value={editingItem.summary}
                            onChange={(e) => setEditingItem({ ...editingItem, summary: e.target.value })}
                            required
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Full Markdown / Article Content</label>
                          <textarea
                            rows={5}
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white font-mono"
                            value={editingItem.content}
                            onChange={(e) => setEditingItem({ ...editingItem, content: e.target.value })}
                            required
                          />
                        </div>
                      </>
                    )}

                    {/* TESTIMONIAL CMS FIELDS */}
                    {editorType === 'testimonial' && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Author Name</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                              value={editingItem.authorName}
                              onChange={(e) => setEditingItem({ ...editingItem, authorName: e.target.value })}
                              required
                            />
                          </div>
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Platform Provider</label>
                            <select
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                              value={editingItem.platform}
                              onChange={(e) => setEditingItem({ ...editingItem, platform: e.target.value })}
                              required
                            >
                              <option value="LinkedIn">LinkedIn</option>
                              <option value="Google">Google Review</option>
                              <option value="Clutch">Clutch Platform</option>
                              <option value="Direct">Direct Verification</option>
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Role / Title</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                              value={editingItem.role}
                              onChange={(e) => setEditingItem({ ...editingItem, role: e.target.value })}
                              required
                            />
                          </div>
                          <div className="flex flex-col gap-1.5">
                            <label className="text-[10px] font-mono text-zinc-500 uppercase">Company Name</label>
                            <input
                              type="text"
                              className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                              value={editingItem.company}
                              onChange={(e) => setEditingItem({ ...editingItem, company: e.target.value })}
                              required
                            />
                          </div>
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] font-mono text-zinc-500 uppercase">Testimonial Quote Text</label>
                          <textarea
                            rows={3}
                            className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white"
                            value={editingItem.text}
                            onChange={(e) => setEditingItem({ ...editingItem, text: e.target.value })}
                            required
                          />
                        </div>
                      </>
                    )}

                    {/* Actions */}
                    <div className="flex items-center justify-end gap-3 pt-4 border-t border-zinc-800/80 mt-2">
                      <button
                        type="button"
                        onClick={() => { setEditingItem(null); setEditorType(null); }}
                        className="px-5 py-2.5 text-xs font-medium rounded-xl border border-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex items-center gap-1.5 bg-brand-accent text-black font-semibold text-xs px-6 py-2.5 rounded-xl hover:shadow-[0_0_15px_rgba(245,158,11,0.2)] transition-all cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Save live changes
                      </button>
                    </div>

                  </form>
                </motion.div>
              </div>
            )}

            {/* CMS list renders dynamically depending on active cmsTab */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
              {cmsTab === 'projects' && (
                <div className="divide-y divide-zinc-800">
                  {projects.map((proj) => (
                    <div key={proj.id} className="p-5 flex items-center justify-between hover:bg-zinc-800/20 transition-colors">
                      <div className="flex items-center gap-4">
                        <img src={proj.imageUrl} alt="" className="w-16 h-10 object-cover rounded-lg border border-zinc-800" />
                        <div>
                          <h4 className="text-sm font-semibold text-white">{proj.title}</h4>
                          <p className="text-xs text-zinc-500 font-mono mt-0.5">{proj.clientName} • <span className="text-brand-accent">{proj.category}</span></p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => openEditor(proj, 'project')}
                          className="p-2 rounded-xl text-zinc-400 hover:text-brand-accent hover:bg-zinc-800 transition-all cursor-pointer"
                          title="Edit Case Study"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem(proj.id, 'project')}
                          className="p-2 rounded-xl text-zinc-400 hover:text-red-500 hover:bg-zinc-800 transition-all cursor-pointer"
                          title="Delete Case Study"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {cmsTab === 'clients' && (
                <div className="divide-y divide-zinc-800">
                  {clients.map((cli) => (
                    <div key={cli.id} className="p-5 flex items-center justify-between hover:bg-zinc-800/20 transition-colors">
                      <div>
                        <h4 className="text-sm font-semibold text-white">{cli.name}</h4>
                        <p className="text-xs text-zinc-500 font-mono mt-0.5">{cli.industry} • {cli.timeline}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => openEditor(cli, 'client')}
                          className="p-2 rounded-xl text-zinc-400 hover:text-brand-accent hover:bg-zinc-800 transition-all cursor-pointer"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem(cli.id, 'client')}
                          className="p-2 rounded-xl text-zinc-400 hover:text-red-500 hover:bg-zinc-800 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {cmsTab === 'blogs' && (
                <div className="divide-y divide-zinc-800">
                  {blogs.map((blog) => (
                    <div key={blog.id} className="p-5 flex items-center justify-between hover:bg-zinc-800/20 transition-colors">
                      <div className="flex items-center gap-4">
                        <img src={blog.imageUrl} alt="" className="w-16 h-10 object-cover rounded-lg border border-zinc-800" />
                        <div>
                          <h4 className="text-sm font-semibold text-white">{blog.title}</h4>
                          <p className="text-xs text-zinc-500 font-mono mt-0.5">{blog.publishedAt} • By {blog.author}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => openEditor(blog, 'blog')}
                          className="p-2 rounded-xl text-zinc-400 hover:text-brand-accent hover:bg-zinc-800 transition-all cursor-pointer"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem(blog.id, 'blog')}
                          className="p-2 rounded-xl text-zinc-400 hover:text-red-500 hover:bg-zinc-800 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {cmsTab === 'testimonials' && (
                <div className="divide-y divide-zinc-800">
                  {testimonials.map((test) => (
                    <div key={test.id} className="p-5 flex items-center justify-between hover:bg-zinc-800/20 transition-colors">
                      <div className="max-w-2xl">
                        <h4 className="text-sm font-semibold text-white">"{test.text.slice(0, 110)}..."</h4>
                        <p className="text-xs text-zinc-500 font-mono mt-1">{test.authorName} • {test.role} at <span className="text-brand-accent">{test.company}</span> ({test.platform})</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => openEditor(test, 'testimonial')}
                          className="p-2 rounded-xl text-zinc-400 hover:text-brand-accent hover:bg-zinc-800 transition-all cursor-pointer"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteItem(test.id, 'testimonial')}
                          className="p-2 rounded-xl text-zinc-400 hover:text-red-500 hover:bg-zinc-800 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}

        {/* TAB 3: LEADS INBOX */}
        {activeTab === 'leads' && (
          <div className="flex flex-col gap-6 animate-fadeIn">
            <div className="flex items-center justify-between pb-4 border-b border-zinc-900">
              <span className="text-xs font-mono text-zinc-500">
                ACTIVE PIPELINE: <span className="text-white font-medium">{leads.length} REQUESTS RECEIVED</span>
              </span>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {leads.length === 0 ? (
                <div className="p-12 text-center bg-zinc-900 border border-zinc-800 rounded-2xl">
                  <Inbox className="w-8 h-8 text-zinc-600 mx-auto mb-3" />
                  <p className="text-zinc-400 font-light text-sm">Your leads pipeline is currently clear.</p>
                </div>
              ) : (
                leads.map((lead) => (
                  <div key={lead.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl flex flex-col gap-4 relative overflow-hidden">
                    {/* Status badge and metadata */}
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-800 pb-4">
                      <div>
                        <h3 className="text-base font-semibold text-white">{lead.name}</h3>
                        <p className="text-xs text-zinc-400 font-mono mt-0.5">{lead.email} • {lead.company || 'Private Professional'}</p>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-mono px-2.5 py-1 rounded-full border ${
                          lead.status === 'New' ? 'bg-amber-500/10 border-amber-500/20 text-amber-500' :
                          lead.status === 'In Progress' ? 'bg-blue-500/10 border-blue-500/20 text-blue-500' :
                          lead.status === 'Contacted' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' :
                          'bg-zinc-800 border-zinc-700 text-zinc-500'
                        }`}>
                          {lead.status.toUpperCase()}
                        </span>
                        <span className="text-[10px] font-mono text-zinc-500">
                          {new Date(lead.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    {/* Inquiry Message */}
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-mono text-zinc-500 uppercase">Service Requested</span>
                      <p className="text-sm font-semibold text-brand-accent">{lead.serviceType}</p>
                      
                      <span className="text-[10px] font-mono text-zinc-500 uppercase mt-3">Message Submission</span>
                      <p className="text-sm text-zinc-300 font-light leading-relaxed">{lead.message}</p>
                    </div>

                    {/* Action Pipeline Controllers */}
                    <div className="flex items-center justify-end gap-2 pt-4 border-t border-zinc-800 mt-2">
                      <span className="text-xs font-mono text-zinc-500 mr-auto">Advance Pipeline Status:</span>
                      
                      <button
                        onClick={() => updateLeadStatus(lead.id, 'In Progress')}
                        className={`px-3 py-1.5 text-xs font-mono rounded-lg transition-all border cursor-pointer ${
                          lead.status === 'In Progress' ? 'bg-blue-500 text-white border-blue-600' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        In Progress
                      </button>

                      <button
                        onClick={() => updateLeadStatus(lead.id, 'Contacted')}
                        className={`px-3 py-1.5 text-xs font-mono rounded-lg transition-all border cursor-pointer ${
                          lead.status === 'Contacted' ? 'bg-emerald-500 text-white border-emerald-600' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        Contacted / Success
                      </button>

                      <button
                        onClick={() => updateLeadStatus(lead.id, 'Archived')}
                        className={`px-3 py-1.5 text-xs font-mono rounded-lg transition-all border cursor-pointer ${
                          lead.status === 'Archived' ? 'bg-zinc-800 text-zinc-300 border-zinc-700' : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        Archive
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 4: STRIPE PAYMENTS */}
        {activeTab === 'billing' && (
          <div className="flex flex-col gap-8 animate-fadeIn">
            {/* Header summary info */}
            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl flex flex-wrap items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-brand-accent/5 border border-brand-accent/20 rounded-2xl text-brand-accent">
                  <CreditCard className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-white">Stripe Live Sync Engine</h3>
                  <p className="text-xs text-zinc-400 font-mono mt-0.5">Secure payment subscriptions processed via custom webhook triggers.</p>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div>
                  <span className="text-[10px] font-mono text-zinc-500 block uppercase">Monthly Run Rate</span>
                  <span className="text-2xl font-display font-semibold text-white">${analytics.monthlyRevenue.toLocaleString()}</span>
                </div>
                <div className="border-l border-zinc-800 h-8" />
                <div>
                  <span className="text-[10px] font-mono text-zinc-500 block uppercase">Active Accounts</span>
                  <span className="text-2xl font-display font-semibold text-white">{analytics.activeSubscriptions}</span>
                </div>
              </div>
            </div>

            {/* List of active Stripe accounts */}
            <div>
              <h3 className="text-sm font-mono font-medium text-zinc-400 mb-4 uppercase tracking-wider">Live subscription ledgers</h3>
              <div className="grid grid-cols-1 gap-4">
                {subscriptions.map((sub) => (
                  <div key={sub.id} className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-center text-zinc-400 font-mono text-sm font-semibold uppercase mt-0.5">
                        {sub.clientName.slice(0, 2)}
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-white">{sub.clientName}</h4>
                        <p className="text-xs text-zinc-500 font-mono mt-0.5">{sub.email}</p>
                        <p className="text-xs text-zinc-400 font-light mt-1 bg-zinc-950 px-2 py-0.5 rounded-full inline-block border border-zinc-800">{sub.planName}</p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-8 md:text-right">
                      <div>
                        <span className="text-[10px] font-mono text-zinc-500 block uppercase">Billing Amount</span>
                        <span className="text-sm font-semibold text-white">${sub.amount.toLocaleString()}<span className="text-xs text-zinc-500 font-light font-mono">/{sub.interval === 'monthly' ? 'mo' : 'yr'}</span></span>
                      </div>

                      <div>
                        <span className="text-[10px] font-mono text-zinc-500 block uppercase">Status</span>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full inline-block mt-0.5 ${
                          sub.status === 'active' ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border border-red-500/20 text-red-400'
                        }`}>
                          {sub.status.toUpperCase()}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => toggleSubscriptionStatus(sub.id)}
                          className={`px-3 py-2 rounded-xl text-xs font-mono transition-all border cursor-pointer ${
                            sub.status === 'active'
                              ? 'border-red-900/40 text-red-400 hover:bg-red-950/20'
                              : 'border-emerald-900/40 text-emerald-400 hover:bg-emerald-950/20'
                          }`}
                        >
                          {sub.status === 'active' ? 'Cancel Contract' : 'Reactivate Plan'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Simulated Transactions Ledger */}
            <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl">
              <h3 className="text-sm font-mono font-medium text-zinc-400 mb-4 uppercase tracking-wider">Simulated Stripe Event Logs</h3>
              <div className="font-mono text-xs text-zinc-500 flex flex-col gap-2.5 max-h-48 overflow-y-auto">
                <div className="flex items-center justify-between text-zinc-400">
                  <span>[2026-06-29 10:24:01] event: checkout.session.completed • customer: Rebecca Alvarez</span>
                  <span className="text-emerald-400">+$3,450.00</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>[2026-06-28 15:42:19] event: invoice.paid • customer: Nomad Nest Hospitality</span>
                  <span className="text-zinc-300">+$3,450.00</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>[2026-06-27 09:12:05] event: customer.subscription.created • plan: Executive Voice Pro</span>
                  <span className="text-zinc-500">active status logged</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>[2026-06-25 18:01:34] event: payment_intent.succeeded • customer: Aura Aesthetics</span>
                  <span className="text-zinc-300">+$4,800.00</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>[2026-06-20 11:32:41] event: invoice.created • recurring billing generated</span>
                  <span className="text-zinc-500">sys logs ok</span>
                </div>
              </div>
            </div>

          </div>
        )}

      </div>
    </section>
  );
}
