/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Shield, ArrowRight, Mail, Phone, MapPin, Linkedin, Sparkles, Check } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
  isAdminLoggedIn: boolean;
}

export default function Footer({ onNavigate, isAdminLoggedIn }: FooterProps) {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    // Simulate adding to leads/newsletter cache in localStorage
    try {
      const newsletters = JSON.parse(localStorage.getItem('techrooot_cms_newsletters') || '[]');
      newsletters.push({ email, timestamp: new Date().toISOString() });
      localStorage.setItem('techrooot_cms_newsletters', JSON.stringify(newsletters));
    } catch (err) {}
    
    setSubscribed(true);
    setEmail('');
    setTimeout(() => setSubscribed(false), 5000);
  };

  return (
    <footer id="global-site-footer" className="bg-zinc-950 border-t border-zinc-900 pt-20 pb-12 mt-20">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
        {/* Brand Profile */}
        <div className="flex flex-col gap-6">
          <button
            id="footer-logo-btn"
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 self-start cursor-pointer text-left"
          >
            <span className="font-display font-bold text-2xl tracking-tight text-white">
              Tech<span className="text-brand-accent font-light">Rooot</span>
            </span>
            <div className="w-2 h-2 rounded-full bg-brand-accent animate-pulse" />
          </button>
          <p className="text-sm text-zinc-400 leading-relaxed font-light">
            TechRooot is an elite creative growth studio building high-conversion websites, managing high-authority social profiles, optimizing premium hospitality portfolios, and integrating AI automations to multiply business revenue.
          </p>
          <div className="flex items-center gap-3">
            <a
              id="footer-social-linkedin"
              href="https://linkedin.com"
              target="_blank"
              rel="noreferrer noopener"
              className="p-2.5 rounded-full bg-zinc-900 text-zinc-400 hover:text-brand-accent hover:bg-zinc-800 transition-all border border-zinc-800"
            >
              <Linkedin className="w-4 h-4" />
            </a>
            <button
              id="footer-social-admin-shortcut"
              onClick={() => onNavigate('admin')}
              className="p-2.5 rounded-full bg-zinc-900 text-zinc-400 hover:text-brand-accent hover:bg-zinc-800 transition-all border border-zinc-800 cursor-pointer"
              title="Admin Portal"
            >
              <Shield className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Studio Services Directory */}
        <div className="flex flex-col gap-5">
          <h4 className="text-xs font-mono font-bold tracking-wider text-zinc-500 uppercase">Growth Offerings</h4>
          <ul className="flex flex-col gap-3 text-sm font-light text-zinc-400">
            <li>
              <button onClick={() => onNavigate('services')} className="hover:text-white transition-colors cursor-pointer text-left">
                Website Development
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('services')} className="hover:text-white transition-colors cursor-pointer text-left">
                LinkedIn Executive Branding
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('services')} className="hover:text-white transition-colors cursor-pointer text-left">
                Airbnb & Hospitality Yield
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('services')} className="hover:text-white transition-colors cursor-pointer text-left">
                Performance Advertising (Meta/Google)
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('services')} className="hover:text-white transition-colors cursor-pointer text-left">
                AI Back-office Automation
              </button>
            </li>
          </ul>
        </div>

        {/* Company QuickLinks */}
        <div className="flex flex-col gap-5">
          <h4 className="text-xs font-mono font-bold tracking-wider text-zinc-500 uppercase">Studio Navigation</h4>
          <ul className="flex flex-col gap-3 text-sm font-light text-zinc-400">
            <li>
              <button onClick={() => onNavigate('work')} className="hover:text-white transition-colors cursor-pointer text-left">
                Client Portfolio
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors cursor-pointer text-left">
                Our Story & Timeline
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('testimonials')} className="hover:text-white transition-colors cursor-pointer text-left">
                Social Proof & Reviews
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('careers')} className="hover:text-white transition-colors cursor-pointer text-left">
                Careers / Hiring
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate('blog')} className="hover:text-white transition-colors cursor-pointer text-left">
                Insights & Guides
              </button>
            </li>
          </ul>
        </div>

        {/* Growth Newsletter Signup */}
        <div className="flex flex-col gap-5">
          <h4 className="text-xs font-mono font-bold tracking-wider text-zinc-500 uppercase">Join Weekly Insights</h4>
          <p className="text-sm text-zinc-400 font-light leading-relaxed">
            Get high-converting marketing briefs, website tips, and automation strategies sent straight to your inbox.
          </p>
          <form id="footer-newsletter-form" onSubmit={handleSubscribe} className="relative flex items-center mt-2">
            <input
              type="email"
              placeholder="name@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-brand-accent transition-colors pr-10"
              required
            />
            <button
              type="submit"
              id="footer-newsletter-submit"
              className="absolute right-1 px-3 py-2 text-brand-accent hover:text-white transition-colors rounded-lg bg-zinc-950/40 cursor-pointer"
            >
              {subscribed ? <Check className="w-4 h-4 text-green-500" /> : <ArrowRight className="w-4 h-4" />}
            </button>
          </form>
          {subscribed && (
            <motion.p
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-xs text-green-400 font-light"
            >
              Subscription logged! Check admin portal leads directory.
            </motion.p>
          )}
        </div>
      </div>

      {/* Sub-footer metadata */}
      <div className="max-w-7xl mx-auto px-6 pt-8 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono text-zinc-500">
        <p>© 2026 TechRooot Growth Studio. All rights reserved.</p>
        <div className="flex items-center gap-6">
          <button onClick={() => onNavigate('admin')} className="flex items-center gap-1.5 hover:text-brand-accent transition-colors cursor-pointer">
            <Shield className="w-3.5 h-3.5" />
            {isAdminLoggedIn ? 'Authorized' : 'Authorized Personnel'}
          </button>
          <span>•</span>
          <span className="text-zinc-600">Built for Conversion</span>
        </div>
      </div>
    </footer>
  );
}
