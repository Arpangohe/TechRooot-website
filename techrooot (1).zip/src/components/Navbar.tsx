/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowUpRight, Shield, Activity, DollarSign, LayoutList } from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string, subId?: string | null) => void;
  isAdminLoggedIn: boolean;
  onLogoutAdmin: () => void;
}

export default function Navbar({ currentPage, onNavigate, isAdminLoggedIn, onLogoutAdmin }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Work', value: 'work' },
    { label: 'Services', value: 'services' },
    { label: 'Clients', value: 'clients' },
    { label: 'Industries', value: 'industries' },
    { label: 'Testimonials', value: 'testimonials' },
    { label: 'Insights', value: 'blog' },
    { label: 'About', value: 'about' },
    { label: 'Careers', value: 'careers' },
    { label: 'Contact', value: 'contact' },
  ];

  return (
    <header
      id="main-nav-header"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-brand-bg/85 backdrop-blur-md border-b border-white/10 py-4' : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <button
          id="nav-logo-btn"
          onClick={() => {
            onNavigate('home');
            setIsOpen(false);
          }}
          className="flex items-center gap-2 group cursor-pointer"
        >
          <div className="w-8 h-8 bg-brand-accent rounded-full flex items-center justify-center text-black font-black text-lg italic transition-transform group-hover:rotate-12">R</div>
          <span className="text-2xl font-bold tracking-tighter uppercase text-white group-hover:text-brand-accent transition-colors">
            TechRooot
          </span>
        </button>

        {/* Desktop Navigation */}
        <nav id="desktop-navbar" className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => {
            const isActive = currentPage === item.value;
            return (
              <button
                key={item.value}
                id={`nav-item-btn-${item.value}`}
                onClick={() => onNavigate(item.value)}
                className={`relative px-4 py-2 text-sm font-medium rounded-full cursor-pointer transition-colors ${
                  isActive ? 'text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="active-nav-bubble"
                    className="absolute inset-0 bg-zinc-900 rounded-full -z-10 border border-zinc-800"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Action CTAs */}
        <div className="hidden lg:flex items-center gap-4">
          {isAdminLoggedIn ? (
            <div className="flex items-center gap-2">
              <button
                id="navbar-admin-dashboard-btn"
                onClick={() => onNavigate('admin')}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-medium rounded-full border border-brand-accent/30 text-brand-accent bg-brand-accent/5 hover:bg-brand-accent/10 transition-all"
              >
                <Shield className="w-3.5 h-3.5 animate-pulse" />
                Portal
              </button>
              <button
                id="navbar-admin-logout-btn"
                onClick={onLogoutAdmin}
                className="px-3 py-1.5 text-xs font-mono font-medium rounded-full border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-900 transition-all"
              >
                Logout
              </button>
            </div>
          ) : (
            <button
              id="navbar-quick-admin-login-btn"
              onClick={() => onNavigate('admin')}
              className="text-zinc-500 hover:text-brand-accent p-1 transition-colors"
              title="Admin CMS Portal"
            >
              <Shield className="w-4 h-4" />
            </button>
          )}

          <button
            id="nav-cta-btn-desktop"
            onClick={() => onNavigate('contact')}
            className="flex items-center gap-1.5 border border-white/20 px-6 py-2 rounded-full text-[10px] uppercase tracking-widest font-bold hover:bg-white hover:text-black transition-all group cursor-pointer"
          >
            Book a Call
            <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex items-center gap-3 lg:hidden">
          {isAdminLoggedIn && (
            <button
              id="navbar-mobile-portal-indicator"
              onClick={() => onNavigate('admin')}
              className="p-2 text-brand-accent bg-brand-accent/5 rounded-full border border-brand-accent/20"
            >
              <Shield className="w-4 h-4" />
            </button>
          )}
          <button
            id="mobile-nav-toggle-btn"
            onClick={() => setIsOpen(!isOpen)}
            className="p-2.5 rounded-full bg-zinc-900 text-white border border-zinc-800 hover:bg-zinc-800 transition-colors"
          >
            {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="mobile-nav-drawer-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="fixed inset-0 top-[73px] bg-black/90 backdrop-blur-lg z-40 lg:hidden flex flex-col justify-between p-8"
          >
            <motion.nav
              id="mobile-nav-menu"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ delay: 0.1 }}
              className="flex flex-col gap-4 mt-4"
            >
              {navItems.map((item, idx) => {
                const isActive = currentPage === item.value;
                return (
                  <button
                    key={item.value}
                    id={`nav-item-btn-mobile-${item.value}`}
                    onClick={() => {
                      onNavigate(item.value);
                      setIsOpen(false);
                    }}
                    className={`text-left text-2xl font-display font-medium tracking-tight py-2 transition-all ${
                      isActive ? 'text-brand-accent pl-2 border-l-2 border-brand-accent' : 'text-zinc-300 hover:text-white hover:pl-2'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </motion.nav>

            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              transition={{ delay: 0.2 }}
              className="flex flex-col gap-4 border-t border-zinc-900 pt-6"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-zinc-500">ADMIN CONTROL</span>
                <button
                  id="mobile-nav-portal-shortcut"
                  onClick={() => {
                    onNavigate('admin');
                    setIsOpen(false);
                  }}
                  className="flex items-center gap-1.5 text-sm font-mono text-zinc-400 hover:text-brand-accent transition-colors"
                >
                  <Shield className="w-4 h-4" />
                  {isAdminLoggedIn ? 'Admin Portal' : 'Staff Login'}
                </button>
              </div>

              <button
                id="nav-cta-btn-mobile"
                onClick={() => {
                  onNavigate('contact');
                  setIsOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 bg-brand-accent text-black font-medium py-4 rounded-xl hover:shadow-[0_0_20px_rgba(245,158,11,0.4)] transition-all cursor-pointer"
              >
                Book a Strategic Consultation
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
