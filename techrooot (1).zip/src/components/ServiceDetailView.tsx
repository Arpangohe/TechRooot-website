import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowLeft, ArrowRight, ArrowUpRight, Check, CheckCircle, Send, Sparkles, Laptop, Activity, Target, HelpCircle, ChevronRight
} from 'lucide-react';
import { Service, Project, Lead } from '../types';

interface ServiceDetailViewProps {
  service: Service;
  projects: Project[];
  onBack: () => void;
  onNavigate: (page: string, subId?: string | null) => void;
  setLeads: React.Dispatch<React.SetStateAction<Lead[]>>;
  setAnalytics: React.Dispatch<React.SetStateAction<any>>;
}

const SERVICE_PROJECT_MAP: Record<string, string> = {
  'web-dev': 'aura-clinic',
  'linkedin-growth': 'apex-partners',
  'airbnb-mgmt': 'nomad-nest',
  'ai-automation': 'sustain-ai',
  'branding': 'nomad-nest',
  'performance-marketing': 'aura-clinic',
};

export default function ServiceDetailView({
  service,
  projects,
  onBack,
  onNavigate,
  setLeads,
  setAnalytics,
}: ServiceDetailViewProps) {
  // Local form state
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientCompany, setClientCompany] = useState('');
  const [clientBrief, setClientBrief] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Find related case study
  const relatedProjectId = SERVICE_PROJECT_MAP[service.id];
  const relatedProject = projects.find((p) => p.id === relatedProjectId);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName || !clientEmail || !clientBrief) return;

    setIsSubmitting(true);

    // Simulate database write delay
    setTimeout(() => {
      const newLead: Lead = {
        id: `lead-service-${Date.now()}`,
        name: clientName,
        email: clientEmail,
        company: clientCompany || 'Inbound Lead',
        serviceType: service.title,
        message: clientBrief,
        status: 'New',
        timestamp: new Date().toISOString(),
      };

      // Add to leads state
      setLeads((prev) => [newLead, ...prev]);

      // Update analytics
      setAnalytics((prev: any) => ({
        ...prev,
        totalLeads: prev.totalLeads + 1,
        visitors: prev.visitors + 1, // Simulate a user action trigger
      }));

      setIsSubmitting(false);
      setSubmitSuccess(true);

      // Reset fields
      setClientName('');
      setClientEmail('');
      setClientCompany('');
      setClientBrief('');

      // Auto-dismiss success message
      setTimeout(() => {
        setSubmitSuccess(false);
      }, 6000);
    }, 800);
  };

  const handleScrollToForm = () => {
    const el = document.getElementById('service-inquiry-form');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="flex flex-col gap-12"
    >
      {/* Dynamic Sub-page Header */}
      <div className="border-b border-white/10 pb-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <button
            onClick={onBack}
            className="group text-xs font-mono text-zinc-500 hover:text-brand-accent mb-4 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5 transition-transform group-hover:-translate-x-0.5" />
            Back to All Services
          </button>
          
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 bg-brand-accent rounded-full animate-pulse" />
            <p className="text-[10px] font-mono text-brand-accent uppercase tracking-widest font-bold">
              TechRooot {service.category} division
            </p>
          </div>
          
          <h1 className="font-display font-black text-4xl sm:text-5xl text-white tracking-tighter uppercase leading-none">
            {service.title}
          </h1>
        </div>

        <button
          onClick={handleScrollToForm}
          className="bg-brand-accent text-black font-bold text-xs uppercase tracking-wider px-6 py-3.5 rounded-sm hover:shadow-[0_0_20px_rgba(163,230,53,0.3)] transition-all cursor-pointer hover:scale-102"
        >
          Book This Service
        </button>
      </div>

      {/* Main Grid: Details, Who is it for, Benefits, Deliverables */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left: Overview, Audience, Deliverables */}
        <div className="lg:col-span-7 flex flex-col gap-10">
          
          {/* Detailed Brief */}
          <div className="bg-zinc-900/30 border border-white/5 p-8 rounded-2xl relative overflow-hidden group hover:border-white/10 transition-colors">
            <div className="absolute top-0 right-0 w-24 h-24 bg-brand-accent/5 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
            <h3 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-widest mb-4 flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-brand-accent" />
              Service Brief
            </h3>
            <p className="text-sm sm:text-base text-zinc-300 font-light leading-relaxed">
              {service.fullDetails}
            </p>
          </div>

          {/* Target Audience */}
          <div className="bg-zinc-900/30 border border-white/5 p-8 rounded-2xl hover:border-white/10 transition-colors">
            <h3 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-widest mb-4">
              Who Is It For?
            </h3>
            <p className="text-sm text-zinc-300 font-light leading-relaxed mb-4">
              {service.whoIsItFor}
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <CheckCircle className="w-3.5 h-3.5 text-brand-accent shrink-0" />
                <span>Premium positioning focused</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <CheckCircle className="w-3.5 h-3.5 text-brand-accent shrink-0" />
                <span>Conversion and growth obsessed</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <CheckCircle className="w-3.5 h-3.5 text-brand-accent shrink-0" />
                <span>Seeking passive/automated scale</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <CheckCircle className="w-3.5 h-3.5 text-brand-accent shrink-0" />
                <span>High ticket service & B2B brands</span>
              </div>
            </div>
          </div>

          {/* Deliverables List */}
          <div className="bg-zinc-900/30 border border-white/5 p-8 rounded-2xl hover:border-white/10 transition-colors">
            <h3 className="text-xs font-mono font-bold text-zinc-500 uppercase tracking-widest mb-6">
              Core Deliverables & Outputs
            </h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {service.deliverables.map((deliv, idx) => (
                <li key={idx} className="flex items-start gap-3 bg-zinc-950/40 p-4 rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                  <div className="w-6 h-6 rounded-md bg-brand-accent/10 border border-brand-accent/20 flex items-center justify-center text-brand-accent text-xs font-mono shrink-0">
                    {idx + 1}
                  </div>
                  <span className="text-xs sm:text-sm text-zinc-300 font-light">{deliv}</span>
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* Right: Key Benefits & Outcomes */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          
          <div className="bg-zinc-900/30 border border-white/15 p-8 rounded-2xl relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/3 rounded-full blur-3xl pointer-events-none" />
            
            <h3 className="text-xs font-mono font-bold text-brand-accent uppercase tracking-widest mb-6 flex items-center gap-2">
              <Check className="w-4 h-4 text-brand-accent" />
              Key Business Benefits
            </h3>
            
            <ul className="flex flex-col gap-5">
              {service.benefits.map((b, idx) => (
                <li key={idx} className="text-xs sm:text-sm text-zinc-300 font-light leading-relaxed flex gap-3 items-start">
                  <div className="w-1.5 h-1.5 rounded-full bg-brand-accent shrink-0 mt-1.5" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 pt-6 border-t border-white/10">
              <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block mb-1">
                Typical Performance Thresholds
              </span>
              <p className="text-xs text-white/90 font-mono leading-relaxed bg-black/40 p-3.5 rounded-lg border border-white/5">
                ⚡ {service.sampleWorkSummary}
              </p>
            </div>
          </div>

          {/* Quick trust visual */}
          <div className="bg-zinc-900/10 border border-white/5 p-6 rounded-2xl text-center flex flex-col items-center gap-2">
            <span className="text-xl">🤝</span>
            <p className="text-xs text-white font-semibold">100% Client Satisfaction Guarantee</p>
            <p className="text-[10px] text-zinc-500 leading-relaxed">
              We operate under transparent SLA schedules. If we fail to deliver milestones on-time, we credit back prorated operational retainer margins.
            </p>
          </div>

        </div>

      </div>

      {/* Section: Process Timeline */}
      <div className="flex flex-col gap-8 border-t border-white/10 pt-16">
        <div className="flex flex-col gap-2">
          <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-bold">The Blueprint</span>
          <h3 className="font-display font-black text-2xl sm:text-3xl text-white uppercase tracking-tight">
            Our Methodical Execution Process
          </h3>
          <p className="text-xs sm:text-sm text-zinc-400 font-light max-w-xl">
            We work in highly predictable, structured phases, keeping your team fully informed while maintaining zero operational clutter.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {service.process.map((p, idx) => (
            <div
              key={p.step}
              className="bg-zinc-900/30 p-6 rounded-xl border border-white/5 hover:border-white/10 transition-all duration-300 relative group flex flex-col justify-between h-full"
            >
              <div>
                <div className="flex justify-between items-start mb-4">
                  <span className="text-xs font-mono font-bold text-zinc-600 group-hover:text-brand-accent transition-colors">
                    PHASE {p.step}
                  </span>
                  <span className="text-3xl font-display font-black text-zinc-800/80 group-hover:text-brand-accent/20 transition-colors">
                    {p.step}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-white mb-2 leading-snug group-hover:text-brand-accent transition-colors">
                  {p.title}
                </h4>
              </div>
              <p className="text-xs text-zinc-400 font-light leading-relaxed mt-2">
                {p.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Section: Showcases Sample Work (Dynamic) */}
      {relatedProject && (
        <div className="flex flex-col gap-8 border-t border-white/10 pt-16">
          <div className="flex flex-col gap-2">
            <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-bold">Case Study In Action</span>
            <h3 className="font-display font-black text-2xl sm:text-3xl text-white uppercase tracking-tight">
              Real-World Outcomes for {relatedProject.clientName}
            </h3>
          </div>

          <div className="bg-zinc-900/40 border border-white/10 rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
            
            {/* Visual thumb */}
            <div className="lg:col-span-5 h-64 lg:h-auto min-h-[250px] relative">
              <img
                src={relatedProject.imageUrl}
                alt={relatedProject.clientName}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-brand-bg via-transparent to-transparent opacity-90" />
              
              <div className="absolute bottom-6 left-6 right-6 z-10">
                <span className="text-[10px] font-mono text-brand-accent bg-zinc-950/80 px-2.5 py-1 rounded border border-brand-accent/20 uppercase tracking-wider">
                  {relatedProject.category}
                </span>
                <h4 className="font-display font-bold text-xl text-white mt-3 leading-none">
                  {relatedProject.clientName}
                </h4>
                <p className="text-[10px] text-zinc-400 font-mono mt-1">{relatedProject.industry}</p>
              </div>
            </div>

            {/* Stats and text */}
            <div className="lg:col-span-7 p-8 flex flex-col justify-between gap-6">
              <div className="flex flex-col gap-4">
                <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest block">The Opportunity realized</span>
                <p className="text-sm text-zinc-300 font-light leading-relaxed">
                  {relatedProject.summary}
                </p>

                {/* Grid of outcome metrics */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  {relatedProject.results.map((r, idx) => (
                    <div key={idx} className="bg-zinc-950/50 p-4 rounded-xl border border-white/5 flex flex-col gap-1">
                      <span className="text-[10px] text-zinc-500 font-mono uppercase truncate">{r.metric}</span>
                      <span className="text-2xl font-display font-bold text-brand-accent leading-none">{r.value}</span>
                      <span className="text-[9px] text-zinc-400 font-light leading-tight">{r.subtext}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-white/5 pt-4 mt-2">
                <div className="flex items-center gap-10">
                  <div>
                    <span className="text-[9px] text-zinc-500 font-mono uppercase block">Scale Phase</span>
                    <span className="text-xs text-white font-semibold">{relatedProject.timeline}</span>
                  </div>
                </div>

                <button
                  onClick={() => onNavigate('case-study', relatedProject.id)}
                  className="flex items-center gap-1.5 text-xs text-white hover:text-brand-accent transition-colors font-mono cursor-pointer"
                >
                  Explore Detailed Case Study <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* Section: Interactive FAQs (Collapsible Details) */}
      <div className="flex flex-col gap-8 border-t border-white/10 pt-16">
        <div className="flex flex-col gap-2">
          <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-bold">Direct Answers</span>
          <h3 className="font-display font-black text-2xl sm:text-3xl text-white uppercase tracking-tight">
            Service FAQs
          </h3>
        </div>

        <div className="flex flex-col gap-4 max-w-3xl">
          {service.faqs.map((faq, idx) => (
            <details
              key={idx}
              className="group bg-zinc-900/20 border border-white/5 rounded-xl p-5 [&_summary::-webkit-details-marker]:hidden"
            >
              <summary className="flex justify-between items-center font-bold text-white cursor-pointer list-none select-none text-sm sm:text-base hover:text-brand-accent transition-colors">
                <span className="flex items-center gap-3">
                  <span className="text-brand-accent font-mono">0{idx + 1}.</span>
                  {faq.question}
                </span>
                <span className="transition duration-300 group-open:-rotate-180 text-brand-accent text-xl font-mono">
                  +
                </span>
              </summary>
              <div className="text-xs sm:text-sm text-zinc-400 font-light mt-4 pl-8 leading-relaxed border-t border-white/5 pt-4">
                {faq.answer}
              </div>
            </details>
          ))}
        </div>
      </div>

      {/* Section: Custom Interactive Lead Capture CTA */}
      <div
        id="service-inquiry-form"
        className="border-t border-white/10 pt-16 scroll-mt-24"
      >
        <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 border border-white/10 rounded-3xl p-8 sm:p-12 relative overflow-hidden max-w-3xl mx-auto">
          <div className="absolute top-0 right-0 w-80 h-80 bg-brand-accent/5 rounded-full blur-[100px] pointer-events-none" />
          
          <div className="text-center max-w-xl mx-auto mb-10 flex flex-col gap-3">
            <span className="text-xs font-mono text-brand-accent uppercase tracking-widest font-bold block">
              Inquire Now
            </span>
            <h3 className="font-display font-black text-3xl sm:text-4xl text-white uppercase tracking-tighter leading-none">
              Initiate Your {service.title} Brief
            </h3>
            <p className="text-xs sm:text-sm text-zinc-400 font-light leading-relaxed">
              Submit your project brief below. Our technical partners will review your economic parameters and follow up within 12 business hours.
            </p>
          </div>

          {submitSuccess ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-brand-accent/10 border border-brand-accent/25 p-8 rounded-2xl text-center flex flex-col items-center gap-4"
            >
              <div className="w-12 h-12 rounded-full bg-brand-accent flex items-center justify-center text-black">
                <CheckCircle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-display font-bold text-lg text-white mb-1">Brief Submitted Successfully</h4>
                <p className="text-xs text-zinc-400 max-w-md mx-auto leading-relaxed">
                  We have cataloged your parameters inside our leads engine. Our partners are initiating discovery. You can track this lead in real-time within our <strong>Admin Dashboard</strong> under the "Leads" tab.
                </p>
              </div>
              <button
                onClick={() => setSubmitSuccess(false)}
                className="text-xs text-brand-accent hover:underline font-mono"
              >
                Submit another inquiry
              </button>
            </motion.div>
          ) : (
            <form onSubmit={handleFormSubmit} className="flex flex-col gap-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-zinc-500 uppercase font-semibold">Your Name</label>
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="bg-zinc-950 border border-white/10 rounded-sm px-4 py-3 text-xs text-white focus:border-brand-accent focus:outline-none transition-colors font-mono"
                    placeholder="Arpan Gohe"
                  />
                </div>
                
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-zinc-500 uppercase font-semibold">Email Address</label>
                  <input
                    type="email"
                    required
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    className="bg-zinc-950 border border-white/10 rounded-sm px-4 py-3 text-xs text-white focus:border-brand-accent focus:outline-none transition-colors font-mono"
                    placeholder="arpan@example.com"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-mono text-zinc-500 uppercase font-semibold">Company Name (Optional)</label>
                <input
                  type="text"
                  value={clientCompany}
                  onChange={(e) => setClientCompany(e.target.value)}
                  className="bg-zinc-950 border border-white/10 rounded-sm px-4 py-3 text-xs text-white focus:border-brand-accent focus:outline-none transition-colors font-mono"
                  placeholder="Aesthetic Clinic Group"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-mono text-zinc-500 uppercase font-semibold">Project Brief & Goals</label>
                <textarea
                  required
                  rows={4}
                  value={clientBrief}
                  onChange={(e) => setClientBrief(e.target.value)}
                  className="bg-zinc-950 border border-white/10 rounded-sm px-4 py-3 text-xs text-white focus:border-brand-accent focus:outline-none transition-colors font-mono resize-none leading-relaxed"
                  placeholder="Explain what you want to achieve, your timeline constraints, or existing bottlenecks..."
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-2 bg-white text-black hover:bg-brand-accent font-bold text-xs uppercase tracking-wider py-4 rounded-sm transition-all cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>Initializing Lead Pipeline...</>
                ) : (
                  <>
                    Submit Project Brief
                    <Send className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>

    </motion.div>
  );
}
