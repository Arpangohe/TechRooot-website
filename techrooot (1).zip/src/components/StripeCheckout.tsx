/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, CreditCard, Lock, Sparkles, X, Star, Calendar, RefreshCw, FileText } from 'lucide-react';
import { StripeSubscription } from '../types';

interface StripeCheckoutProps {
  onSubscriptionCreated: (newSub: StripeSubscription) => void;
  isOpen: boolean;
  onClose: () => void;
}

interface Plan {
  id: string;
  name: string;
  priceMonthly: number;
  priceYearly: number;
  description: string;
  features: string[];
  popular?: boolean;
}

const PLANS: Plan[] = [
  {
    id: 'plan-executive',
    name: 'Executive Voice Pro',
    priceMonthly: 2500,
    priceYearly: 2000,
    description: 'Transform your founder profile into an authority funnel generating consistent inbound sales pipeline opportunities.',
    features: [
      '12 Monthly premium narrative content releases',
      '2 Audiovisual slider carousels designed',
      'Voice Blueprint interview profiling sessions',
      'Targeted LinkedIn DM pipeline triage',
      'Monthly reach analytics reports'
    ]
  },
  {
    id: 'plan-elite',
    name: 'Elite Growth Package',
    priceMonthly: 3450,
    priceYearly: 2800,
    description: 'Our flagship hospitality yield framework. Staging, dynamic optimization, and fully automated operations.',
    popular: true,
    features: [
      'Listing layout copywriting optimization',
      'Dynamic dynamic hourly price modeling',
      'Autonomous guest communication manager setup',
      'Vetted local operation network placements',
      'Superhost rank algorithm insurance'
    ]
  },
  {
    id: 'plan-omni',
    name: 'Omnichannel Scale Package',
    priceMonthly: 4800,
    priceYearly: 4000,
    description: 'Comprehensive brand scaling combining high-performance website development, ads campaign, and AI automations.',
    features: [
      'Premium custom React web development',
      'Meta & Google performance campaign run',
      'Integrated intelligent AI qualification pipelines',
      'Aesthetic brand asset identity overhaul',
      'Bi-weekly scaling consulting consults'
    ]
  }
];

export default function StripeCheckout({ onSubscriptionCreated, isOpen, onClose }: StripeCheckoutProps) {
  const [billingInterval, setBillingInterval] = useState<'monthly' | 'yearly'>('monthly');
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  
  // Checkout process steps
  const [checkoutStep, setCheckoutStep] = useState<'select' | 'payment' | 'success'>('select');

  // Card input states
  const [clientName, setClientName] = useState('');
  const [email, setEmail] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  
  const [processing, setProcessing] = useState(false);
  const [checkoutError, setCheckoutError] = useState('');

  const handleSelectPlan = (plan: Plan) => {
    setSelectedPlan(plan);
    setCheckoutStep('payment');
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Format card number: 4444 4444 4444 4444
    let val = e.target.value.replace(/\D/g, '');
    if (val.length > 16) val = val.slice(0, 16);
    const parts = [];
    for (let i = 0; i < val.length; i += 4) {
      parts.push(val.slice(i, i + 4));
    }
    setCardNumber(parts.join(' '));
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '');
    if (val.length > 4) val = val.slice(0, 4);
    if (val.length > 2) {
      setCardExpiry(`${val.slice(0, 2)}/${val.slice(2)}`);
    } else {
      setCardExpiry(val);
    }
  };

  const handleCvcChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '');
    setCardCvc(val.slice(0, 4));
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlan || !clientName || !email || cardNumber.replace(/\s/g, '').length < 16) {
      setCheckoutError('Please populate all card billing inputs correctly.');
      return;
    }

    setCheckoutError('');
    setProcessing(true);

    // Simulate luxury Stripe gateway animation
    setTimeout(() => {
      setProcessing(false);
      setCheckoutStep('success');
      
      const price = billingInterval === 'monthly' ? selectedPlan.priceMonthly : selectedPlan.priceYearly;
      
      // Emit the successful subscription record to update the database
      const newSub: StripeSubscription = {
        id: `sub-${Date.now()}`,
        clientName,
        email,
        planName: selectedPlan.name,
        amount: price,
        interval: billingInterval,
        status: 'active',
        createdAt: new Date().toISOString().split('T')[0]
      };
      
      onSubscriptionCreated(newSub);
    }, 2800);
  };

  const handleCloseAndReset = () => {
    setCheckoutStep('select');
    setSelectedPlan(null);
    setClientName('');
    setEmail('');
    setCardNumber('');
    setCardExpiry('');
    setCardCvc('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div id="stripe-checkout-modal-overlay" className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-zinc-950 border border-zinc-900 rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-y-auto relative text-left"
      >
        {/* Close Button */}
        <button
          id="stripe-checkout-close-btn"
          onClick={handleCloseAndReset}
          className="absolute top-6 right-6 p-2 rounded-full bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800 transition-all cursor-pointer z-10"
        >
          <X className="w-4.5 h-4.5" />
        </button>

        {/* STEP 1: PLAN SELECTOR */}
        {checkoutStep === 'select' && (
          <div className="p-8 md:p-12">
            <div className="text-center mb-10 max-w-xl mx-auto">
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-brand-accent px-3 py-1 rounded-full bg-brand-accent/5 border border-brand-accent/20">
                Studio Retainers
              </span>
              <h2 className="font-display font-bold text-3xl md:text-4xl text-white tracking-tight mt-3 mb-4">
                Partner with TechRooot
              </h2>
              <p className="text-sm text-zinc-400 font-light">
                Transparent monthly growth subscriptions designed to build authority, maximize bookings, and integrate advanced scaling systems.
              </p>

              {/* Billing Interval Switcher */}
              <div className="flex items-center justify-center gap-3 mt-6">
                <span className={`text-xs font-mono transition-colors ${billingInterval === 'monthly' ? 'text-white' : 'text-zinc-500'}`}>Monthly</span>
                <button
                  id="stripe-billing-interval-switcher"
                  onClick={() => setBillingInterval(billingInterval === 'monthly' ? 'yearly' : 'monthly')}
                  className="w-12 h-6 rounded-full bg-zinc-900 border border-zinc-800 p-1 relative flex items-center transition-colors hover:border-brand-accent/40 cursor-pointer"
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-brand-accent transition-all ${
                      billingInterval === 'yearly' ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
                <span className={`text-xs font-mono transition-colors flex items-center gap-1.5 ${billingInterval === 'yearly' ? 'text-brand-accent font-semibold' : 'text-zinc-500'}`}>
                  Yearly Retainer
                  <span className="bg-brand-accent/10 text-[10px] text-brand-accent px-1.5 py-0.5 rounded-md font-mono font-semibold">Save 20%</span>
                </span>
              </div>
            </div>

            {/* Plans Cards Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
              {PLANS.map((plan) => {
                const price = billingInterval === 'monthly' ? plan.priceMonthly : plan.priceYearly;
                return (
                  <div
                    key={plan.id}
                    id={`stripe-plan-card-${plan.id}`}
                    className={`flex flex-col justify-between p-6 rounded-2xl bg-zinc-900/50 border relative transition-all ${
                      plan.popular
                        ? 'border-brand-accent shadow-[0_0_20px_rgba(245,158,11,0.05)] bg-zinc-900'
                        : 'border-zinc-800/80 hover:border-zinc-700'
                    }`}
                  >
                    {plan.popular && (
                      <span className="absolute -top-3 left-6 text-[10px] font-mono font-bold uppercase tracking-wider bg-brand-accent text-black px-3 py-1 rounded-full flex items-center gap-1">
                        <Star className="w-3 h-3 fill-black" /> Highly Requested
                      </span>
                    )}

                    <div>
                      <h3 className="font-display font-bold text-lg text-white mb-2">{plan.name}</h3>
                      <p className="text-xs text-zinc-400 font-light leading-relaxed mb-4">{plan.description}</p>
                      
                      {/* Pricing Tag */}
                      <div className="flex items-baseline gap-1 mb-6">
                        <span className="font-display font-semibold text-3xl text-white">${price.toLocaleString()}</span>
                        <span className="text-xs text-zinc-500 font-mono">/mo</span>
                      </div>

                      {/* Features Bullet List */}
                      <ul className="flex flex-col gap-3 border-t border-zinc-800/50 pt-5 mb-8">
                        {plan.features.map((feat) => (
                          <li key={feat} className="flex items-start gap-2.5 text-xs font-light text-zinc-400 leading-normal">
                            <Check className="w-4 h-4 text-brand-accent shrink-0 mt-0.5" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <button
                      id={`stripe-plan-select-btn-${plan.id}`}
                      onClick={() => handleSelectPlan(plan)}
                      className={`w-full py-3.5 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                        plan.popular
                          ? 'bg-brand-accent text-black hover:shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                          : 'bg-zinc-800 text-white hover:bg-zinc-700'
                      }`}
                    >
                      Initialize Contract
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* STEP 2: CREDIT CARD GATEWAY FORM */}
        {checkoutStep === 'payment' && selectedPlan && (
          <div className="grid grid-cols-1 lg:grid-cols-12 max-h-[85vh] overflow-hidden">
            {/* Left: Summary */}
            <div className="lg:col-span-5 bg-zinc-900 p-8 border-b lg:border-b-0 lg:border-r border-zinc-800 flex flex-col justify-between">
              <div>
                <button
                  id="stripe-checkout-back-to-plans"
                  onClick={() => setCheckoutStep('select')}
                  className="text-xs font-mono text-zinc-500 hover:text-brand-accent mb-8 flex items-center gap-1.5 cursor-pointer"
                >
                  ← Back to Retainers
                </button>

                <span className="text-[10px] font-mono uppercase tracking-wider text-brand-accent">Checkout Summary</span>
                <h3 className="font-display font-bold text-2xl text-white mt-2 mb-4">{selectedPlan.name}</h3>
                <p className="text-xs text-zinc-400 font-light leading-relaxed mb-6">{selectedPlan.description}</p>

                {/* Ledger items */}
                <div className="flex flex-col gap-3 pt-6 border-t border-zinc-800 font-mono text-xs text-zinc-400">
                  <div className="flex justify-between">
                    <span>Recurring Billing Contract</span>
                    <span className="text-white">Active Superhost Retainer</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Interval Rate</span>
                    <span className="text-white capitalize">{billingInterval} billing</span>
                  </div>
                  <div className="flex justify-between pt-3 border-t border-zinc-800 text-sm font-semibold text-white">
                    <span>Total Due Today</span>
                    <span className="text-brand-accent">
                      ${(billingInterval === 'monthly' ? selectedPlan.priceMonthly : selectedPlan.priceYearly).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-zinc-800/80 text-[10px] text-zinc-500 font-mono flex flex-col gap-1.5">
                <div className="flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-zinc-600" />
                  <span>Stripe Secure TLS 1.3 Encryption</span>
                </div>
                <p>Fully compliant with industry-leading financial security parameters.</p>
              </div>
            </div>

            {/* Right: Realistic Credit Card inputs */}
            <div className="lg:col-span-7 p-8 overflow-y-auto">
              <h3 className="font-display font-bold text-xl text-white mb-6">Billing & Authorization details</h3>

              <form id="stripe-credit-card-form" onSubmit={handleCheckoutSubmit} className="flex flex-col gap-5">
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="stripe-input-client-name" className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Client Full Name</label>
                  <input
                    type="text"
                    id="stripe-input-client-name"
                    required
                    className="bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3.5 text-sm text-white focus:outline-none focus:border-brand-accent transition-colors"
                    placeholder="e.g. Rebecca Alvarez"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label htmlFor="stripe-input-email" className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Business Email Address</label>
                  <input
                    type="email"
                    id="stripe-input-email"
                    required
                    className="bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3.5 text-sm text-white focus:outline-none focus:border-brand-accent transition-colors"
                    placeholder="rebecca@vistascapes.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>

                {/* Simulated Card Wrapper */}
                <div className="p-5 bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl flex flex-col gap-4 relative overflow-hidden mt-2">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/5 rounded-full blur-2xl pointer-events-none" />
                  
                  <div className="flex items-center justify-between text-zinc-500">
                    <CreditCard className="w-6 h-6 text-brand-accent" />
                    <span className="text-[10px] font-mono tracking-widest uppercase font-semibold">Growth Card</span>
                  </div>

                  <div className="flex flex-col gap-1.5 mt-2">
                    <label htmlFor="stripe-input-card-number" className="text-[9px] font-mono text-zinc-600 uppercase tracking-wider">Credit Card Number</label>
                    <input
                      type="text"
                      id="stripe-input-card-number"
                      required
                      pattern="\d{4} \d{4} \d{4} \d{4}"
                      className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-mono text-white focus:outline-none focus:border-brand-accent tracking-widest"
                      placeholder="4242 4242 4242 4242"
                      value={cardNumber}
                      onChange={handleCardNumberChange}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="stripe-input-expiry" className="text-[9px] font-mono text-zinc-600 uppercase tracking-wider">Expiration Date</label>
                      <input
                        type="text"
                        id="stripe-input-expiry"
                        required
                        pattern="(0[1-9]|1[0-2])\/?([0-9]{2})"
                        className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-mono text-white focus:outline-none focus:border-brand-accent text-center"
                        placeholder="MM/YY"
                        value={cardExpiry}
                        onChange={handleExpiryChange}
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="stripe-input-cvc" className="text-[9px] font-mono text-zinc-600 uppercase tracking-wider">Security CVC</label>
                      <input
                        type="password"
                        id="stripe-input-cvc"
                        required
                        pattern="\d{3,4}"
                        className="bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-mono text-white focus:outline-none focus:border-brand-accent text-center tracking-widest"
                        placeholder="•••"
                        value={cardCvc}
                        onChange={handleCvcChange}
                      />
                    </div>
                  </div>
                </div>

                {checkoutError && (
                  <p className="text-xs text-red-400 font-mono mt-1">{checkoutError}</p>
                )}

                <button
                  type="submit"
                  id="stripe-authorize-checkout-btn"
                  disabled={processing}
                  className="w-full flex items-center justify-center gap-2 bg-brand-accent text-black font-semibold py-4 rounded-xl hover:shadow-[0_0_20px_rgba(245,158,11,0.3)] transition-all mt-4 cursor-pointer disabled:opacity-50"
                >
                  {processing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Securing auth token with Stripe...
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      Authorize & Activate Subscription
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        )}

        {/* STEP 3: TRANSACTION SUCCESS SCREEN */}
        {checkoutStep === 'success' && selectedPlan && (
          <div className="p-8 md:p-16 text-center max-w-xl mx-auto flex flex-col items-center gap-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 text-2xl animate-bounce">
              ✓
            </div>

            <div className="flex flex-col gap-2">
              <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest font-semibold">Stripe Payment Succeeded</span>
              <h2 className="font-display font-bold text-3xl text-white tracking-tight">Contract Active</h2>
              <p className="text-sm text-zinc-400 font-light leading-relaxed mt-2">
                Congratulations, **{clientName}**! Your retainer for **{selectedPlan.name}** has been processed successfully. 
                Our executive onboarding pipeline has initialized, and we've logged your credentials in our secure records.
              </p>
            </div>

            {/* Simulated Receipt Invoice info */}
            <div className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-5 font-mono text-xs text-zinc-400 text-left flex flex-col gap-2.5">
              <div className="flex items-center gap-2 text-white pb-3 border-b border-zinc-800">
                <FileText className="w-4 h-4 text-brand-accent" />
                <span className="font-semibold text-xs uppercase">Simulated Receipt Token</span>
              </div>
              <div className="flex justify-between">
                <span>Transaction Ref:</span>
                <span className="text-white">TXN_STRP_{Math.floor(Math.random() * 90000) + 10000}</span>
              </div>
              <div className="flex justify-between">
                <span>Billed To:</span>
                <span className="text-white">{clientName} ({email})</span>
              </div>
              <div className="flex justify-between">
                <span>Subscribed Plan:</span>
                <span className="text-white">{selectedPlan.name}</span>
              </div>
              <div className="flex justify-between pt-3 border-t border-zinc-800 text-white font-semibold">
                <span>Amount Charged:</span>
                <span className="text-brand-accent">
                  ${(billingInterval === 'monthly' ? selectedPlan.priceMonthly : selectedPlan.priceYearly).toLocaleString()} / {billingInterval}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-3 w-full mt-4">
              <button
                id="stripe-success-continue-btn"
                onClick={handleCloseAndReset}
                className="w-full bg-brand-accent text-black font-semibold py-3.5 rounded-xl hover:shadow-[0_0_20px_rgba(245,158,11,0.3)] transition-all cursor-pointer"
              >
                Go back to Website
              </button>
              <p className="text-[10px] text-zinc-500 font-mono">
                Note: This checkout is a simulation. It has created a live record in the **Admin Portal** so you can view transaction analytics immediately.
              </p>
            </div>
          </div>
        )}

      </motion.div>
    </div>
  );
}
