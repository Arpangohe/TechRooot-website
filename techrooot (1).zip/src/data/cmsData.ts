/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Project, Client, Service, BlogPost, Testimonial, Industry, Lead, StripeSubscription, AnalyticsStats } from '../types';

export const INITIAL_SERVICES: Service[] = [
  {
    id: 'web-dev',
    title: 'Website Development',
    category: 'tech',
    description: 'Bespoke, high-performance web platforms engineered with flawless responsive interfaces, custom interactive states, and ultimate speed optimized for client conversion.',
    fullDetails: 'We do not build generic template sites. Our engineered web applications are tailored from scratch using cutting-edge stacks to tell your brand story, build instant trust, and maximize inbound lead conversion. We focus heavily on sub-second load times, flawless typography, fluid transitions, and seamless CMS tools.',
    whoIsItFor: 'Startups, premium service businesses, high-ticket agencies, and corporations seeking to elevate their online positioning and turn casual traffic into qualified revenue.',
    benefits: [
      'Sub-second load speeds for superior search rankings and user retention',
      'Original, editorial-grade designs matching your precise positioning',
      'Fully responsive, fluid layouts looking stunning on everything from mobile screens to 4K displays',
      'Integrated modern custom CMS frameworks for effortless self-updates'
    ],
    process: [
      { step: '01', title: 'Brand Discovery & Content Architecture', description: 'Deep dive into your positioning, client personas, core offerings, and message structure.' },
      { step: '02', title: 'Interactive Prototypes & Editorial Design', description: 'Mapping visual grids, typography hierarchies, and premium interactive animations.' },
      { step: '03', title: 'Flawless Development & Code Engineering', description: 'Writing robust, optimized, accessible, and fast-loading web code.' },
      { step: '04', title: 'Polishing, SEO Optimization & Launch', description: 'Injecting schemas, meta configurations, responsive testing, and seamless server deployment.' }
    ],
    deliverables: [
      'Full-stack or SPA React production-ready codebase',
      'Configured custom metadata and SEO structures',
      'Comprehensive custom interactive components (calculators, schedules, dashboards)',
      'CMS training session and handoff documentation'
    ],
    sampleWorkSummary: 'Clean, lightning-fast digital portfolios, clinic schedulers, and enterprise portals generating up to 210% booking growth.',
    faqs: [
      { question: 'Do you use basic WordPress themes?', answer: 'Never. We build highly optimized React and Vite web platforms with custom code. This ensures zero bloat, ultimate security, and completely original designs.' },
      { question: 'How long does a website project take?', answer: 'A standard high-end website project takes between 3 to 6 weeks from discover to live launch.' }
    ]
  },
  {
    id: 'linkedin-growth',
    title: 'LinkedIn Executive Management',
    category: 'growth',
    description: 'Transforming founders, executives, and business leaders into recognized industry authorities through editorial content curation, networking systems, and outbound pipeline setup.',
    fullDetails: 'Your profile is your digital handshake. We manage your personal LinkedIn presence from end to end—conceptualizing thought leadership hooks, drafting compelling technical or storytelling threads, designing sleek custom slide-decks, and orchestrating targeted organic engagement to drive incoming corporate inquiries.',
    whoIsItFor: 'B2B CEOs, VC general partners, startup founders, consultants, and directors wishing to leverage their expertise for lead gen, talent recruitment, and brand credibility.',
    benefits: [
      'Saves up to 15 hours a week in content ideation, copywriting, and responding',
      'Positions you as the undisputed thought-leader in your precise market niche',
      'Drives direct, warm B2B inbound leads straight into your direct messages',
      'Builds a valuable, high-leverage network of investors, peers, and clients'
    ],
    process: [
      { step: '01', title: 'Voice Alignment & Strategy Audit', description: 'Deep interviews to extract your unique insights, industry stories, and desired positioning.' },
      { step: '02', title: 'Profile Overhaul & Landing Optimization', description: 'Redesigning your banner, writing a high-impact headline, and structuring a conversion-focused featured section.' },
      { step: '03', title: 'Weekly Storytelling Editorial Production', description: 'Drafting authentic posts, thought-leadership pieces, and carousel graphics tailored to your exact voice.' },
      { step: '04', title: 'Organic Amplification & Pipeline Nurture', description: 'Managing interactions, engaging with key industry peers, and forwarding warm inquiries to your sales team.' }
    ],
    deliverables: [
      'Polished LinkedIn profile redesign (banners, copy, custom featured grid)',
      '12 to 16 premium, tailored monthly posts (text, text+image, customized slide carousels)',
      'Active network growth strategy and direct message triage sheets',
      'Monthly analytic reports on reach, engagement, and inbound lead generation'
    ],
    sampleWorkSummary: 'Over 340k organic views and 84 qualified sales calls generated for executive consulting partners.',
    faqs: [
      { question: 'Will my posts sound like generic AI content?', answer: 'Absolutely not. We extract your actual thoughts and stories via brief audio or written notes. The resulting content is authentic, highly detailed, and distinctly human.' },
      { question: 'Is direct outreach spammy?', answer: 'We do not do spam. We focus on thought leadership and organic, warm interactions that prompt prospects to reach out to you first.' }
    ]
  },
  {
    id: 'airbnb-mgmt',
    title: 'Airbnb & Hospitality Management',
    category: 'growth',
    description: 'Maximized revenue generation, listing optimization, styling design, and fully automated operations for boutique rentals and hospitality real-estate.',
    fullDetails: 'We turn standard rental properties into highly profitable hospitality brands. By taking over dynamic price modeling, local experience branding, visual photography direction, listing copy engineering, guest communication, and clean-operations oversight, we consistently push properties to the top 1% of regional performance.',
    whoIsItFor: 'Property owners, real-estate investors, and boutique boutique hotels looking to transition to highly passive, high-yield luxury short-term rental management.',
    benefits: [
      'Dramatically increased occupancy rates and average daily rates (ADR)',
      'Entirely hands-off operations with 24/7 autonomous guest management',
      'Professional luxury interior staging concepts and media direction',
      'Superhost status maintenance for algorithmic search boosting'
    ],
    process: [
      { step: '01', title: 'Property Evaluation & Brand Concept', description: 'Analyzing market supply, pricing potential, and drafting a bespoke styling aesthetic.' },
      { step: '02', title: 'Staging, High-End Media, & Listing Launch', description: 'Guiding interior decor improvements, executing premium photography, and writing psychological descriptions.' },
      { step: '03', title: 'Dynamic Pricing & Algorithmic Marketing', description: 'Implementing software tools to adjust rates hourly based on local events, weather, and historical occupancy patterns.' },
      { step: '04', title: 'Automated Cleaning & Guest Orchestration', description: 'Placing local cleaning crews, auto-checkins, and 24/7 guest helpline managers for perfect feedback.' }
    ],
    deliverables: [
      'Multi-channel listed profiles (Airbnb, VRBO, Booking.com, Direct Book Site)',
      'Staging and professional interior design guides',
      'Dynamic automated pricing model integration',
      'Fully vetted local operations network setup (cleaners, maintenance, key-lock)'
    ],
    sampleWorkSummary: 'Scaled Kyoto and Bali luxury villas to 94% average occupancy and flawless Superhost review streaks.',
    faqs: [
      { question: 'What is your management fee structure?', answer: 'We work on a performance-based revenue split, ensuring our goals are entirely aligned with your rental profitability.' },
      { question: 'Can you handle properties in remote areas?', answer: 'Yes. We build a bulletproof network of local vetted vendors for physical operations while running the digital guest-success team remotely.' }
    ]
  },
  {
    id: 'ai-automation',
    title: 'AI Automation & Custom Workflows',
    category: 'tech',
    description: 'Unleashing immense efficiency by designing custom AI workflows, automated CRM syncing, qualification bots, and automated digital back-offices.',
    fullDetails: 'We audit your manual workflows and replace them with intelligent automated systems. By connecting APIs, fine-tuning lightweight AI models for text parsing, and orchestrating flawless data pipelines, we eliminate human error and compress processes that previously took hours down to seconds.',
    whoIsItFor: 'Growing service businesses, online startups, agencies, and operations managers overwhelmed by repetitive copy-paste tasks, lead routing, and file generation.',
    benefits: [
      'Saves an average of 15 to 30 hours of manual operational labor per week',
      'Eliminates human error in copy-pasting, lead distribution, and invoicing',
      'Gives instant responses to incoming customer inquiries for peak retention',
      'Fully scalable infrastructure that handles infinite volume with zero extra hires'
    ],
    process: [
      { step: '01', title: 'Operational Friction Audit', description: 'Shadowing your team to map every manual data entry, handoff, and delay.' },
      { step: '02', title: 'Automation Architecture Design', description: 'Sketching the logic flow, API integrations, database structures, and guardrails.' },
      { step: '03', title: 'Custom AI Pipeline Engineering', description: 'Connecting tools (e.g., Make, Zapier, custom Node.js) and prompting model processing systems.' },
      { step: '04', title: 'Shadow Running & Client Handoff', description: 'Testing the system in parallel with your team, verifying edge-cases, and deploying with zero downtime.' }
    ],
    deliverables: [
      'Interactive workflow blueprints and step diagrams',
      'Configured AI parsing engines and automated triggers',
      'CRM integration & database auto-sync systems',
      'Real-time status Slack/Discord reporting bots'
    ],
    sampleWorkSummary: 'Integrated dynamic CRM qualifying systems for a SaaS growth provider, compressing inquiry qualification from 4 hours to 90 seconds.',
    faqs: [
      { question: 'Will this replace our human staff?', answer: 'No. It acts as a force multiplier, liberating your existing team from repetitive chores so they can focus on high-leverage client relationships.' },
      { question: 'Do we need custom developer accounts?', answer: 'We set up everything on your behalf under secure credentials, guiding you through a seamless handoff.' }
    ]
  },
  {
    id: 'branding',
    title: 'Branding & Visual Identity',
    category: 'creative',
    description: 'Forging stunning logos, premium typography manuals, editorial brand guidelines, and visual assets designed to attract high-ticket clients.',
    fullDetails: 'A visual identity must command respect. We design editorial brand worlds that convey quality and confidence instantly. Our branding process encompasses comprehensive styling strategy, visual hierarchy guides, custom-tailored palettes, and highly professional asset libraries that keep your brand consistent everywhere.',
    whoIsItFor: 'Businesses rebranding to premium markets, early-stage startups seeking investor credibility, and personal brands scaling to enterprise consulting.',
    benefits: [
      'Instant brand premiumization enabling you to raise prices confidently',
      'Highly cohesive styling manual ensuring flawless look across all channels',
      'Professional vector assets ready for web, physical, and print formats',
      'Distinct visual presence that separates you completely from cheap competitors'
    ],
    process: [
      { step: '01', title: 'Aesthetic Strategy Discovery', description: 'Reviewing market rivals, customer vibes, visual inspirations, and semantic keywords.' },
      { step: '02', title: 'Identity Concepts & Directions', description: 'Developing 3 distinct high-end styling systems (typography, marks, palettes) for review.' },
      { step: '03', title: 'Vector Crafting & Brand Guide', description: 'Polishing the selected concept and expanding it into a comprehensive visual ruleset.' },
      { step: '04', title: 'Asset Package Compilation', description: 'Exporting responsive logo assets, fonts, slide templates, social headers, and media guidelines.' }
    ],
    deliverables: [
      'Responsive logo suite (Primary, Stacked, Icon-only, Dark/Light files)',
      'Tailored brand book (Typography pairings, custom color hex codes, layout spacing rules)',
      'Ready-to-use social media banners and document headers',
      'Professional slide-deck typography templates'
    ],
    sampleWorkSummary: 'Rebranded five-figure consulting agencies, helping them confidently double their project base rates.',
    faqs: [
      { question: 'Do we get copyright ownership?', answer: 'Yes, full commercial IP and legal ownership of all visual assets belong to you upon final payment.' },
      { question: 'What files are delivered?', answer: 'SVG, PDF, EPS, and PNG files in high-resolution, suitable for digital use, signage, and ultra-high-quality printing.' }
    ]
  },
  {
    id: 'performance-marketing',
    title: 'Performance Marketing (Ads)',
    category: 'marketing',
    description: 'High-conversion Google, Meta, and LinkedIn campaign management designed for measurable return on ad spend (ROAS) and automated client acquisition.',
    fullDetails: 'Stop wasting money on vague branding ads. We run mathematical, ROI-obsessed performance marketing. From high-impact ad copy copywriting and visually arrested creative design to advanced interest targeting and landing page funnel optimization, we convert clicks into booked calendars and direct product sales.',
    whoIsItFor: 'E-commerce, premium local services, real estate developers, and high-ticket service companies ready to inject capital to scale client bookings fast.',
    benefits: [
      'Highly predictable client-acquisition engine aligned with unit economics',
      'End-to-end management covering creative design, copywriting, and bid-monitoring',
      'Clear, objective dashboard reports detailing cost-per-lead and acquisition margins',
      'Continuous multivariate A/B testing for steady performance improvement'
    ],
    process: [
      { step: '01', title: 'Unit Economics & Offer Polish', description: 'Assessing your customer lifetime value (LTV) to build highly profitable ad budgets.' },
      { step: '02', title: 'Ad Creative Design & Copywriting', description: 'Producing hook-centric visual assets, video frameworks, and persuasive text.' },
      { step: '03', title: 'Audience Mapping & Campaign Launch', description: 'Setting custom targeting parameters, tracking pixels, and custom custom landing routes.' },
      { step: '04', title: 'Daily Bid Scaling & CRO Optimization', description: 'Pruning underperforming ads, scaling high-ROAS hooks, and refining page conversion rates.' }
    ],
    deliverables: [
      'Configured Meta Pixel, Google Analytics, and Conversion API trackers',
      'Original ad assets (custom graphics, edited vertical video creatives, copy variations)',
      'Optimized, fast-loading, single-focused ad landing page',
      'Real-time reporting portal access and weekly strategy calls'
    ],
    sampleWorkSummary: 'Averaging a consistent 4.2x ROAS across healthcare, luxury rental, and high-ticket professional services.',
    faqs: [
      { question: 'What is the minimum ad spend required?', answer: 'We recommend starting with at least $1,500/month in ad budget to gather sufficient data and fuel algorithmic optimization.' },
      { question: 'Do you guarantee bookings?', answer: 'We guarantee the delivery of qualified impressions, optimized click-throughs, and high landing-page conversion rates based on historically vetted parameters.' }
    ]
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'nomad-nest',
    title: 'Nomad Nest Co.',
    clientName: 'Nomad Nest Hospitality Group',
    category: 'Airbnb Management',
    industry: 'Hospitality / Travel',
    summary: 'Elevating a remote luxury villa to top-tier Superhost status with modern visual branding, dynamic pricing automation, and hands-off operations.',
    beforeLabel: 'Typical Occupancy',
    beforeValue: '42%',
    afterLabel: 'Peak Season Occupancy',
    afterValue: '94%',
    beforeImageUrl: '',
    afterImageUrl: '',
    results: [
      { metric: 'Occupancy Boost', value: '94%', subtext: 'Consistently booked month-over-month' },
      { metric: 'Average Daily Rate', value: '+$185', subtext: 'Increased yield via premium staging' },
      { metric: 'Guest Rating', value: '4.96★', subtext: 'From over 120 verified reviews' }
    ],
    challenge: 'Nomad Nest owned a beautiful modern villa in a highly competitive market, but suffered from inconsistent visibility, zero social presence, manual booking systems, and stale pricing structures that left substantial revenue on the table.',
    strategy: 'We implemented our complete Hospitality Growth Stack. We rebranded the property, directed custom storytelling photography, established dynamic pricing algorithms that adapt hourly, launched targeted Meta Ads pointing to a custom direct booking portal, and fully automated cleaner syncing and check-in workflows.',
    deliverables: [
      'Visual Identity & Premium Brand Asset Kit',
      'Hourly Dynamic Price Integration Profile',
      'Direct-Booking Mobile Optimized Web Portal',
      'Vetted Cleaner Operations Trigger Integrations'
    ],
    timeline: '3 Months',
    testimonialText: 'TechRooot completely revolutionized our rental operations. What used to be a highly stressful side-gig is now a completely passive luxury cash-flow asset.',
    testimonialAuthor: 'Marcus Vance',
    testimonialRole: 'Founder',
    imageUrl: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&q=80&w=1200'
  },
  {
    id: 'aura-clinic',
    title: 'Aura Aesthetic Clinic',
    clientName: 'Aura Aesthetics Group',
    category: 'Website Development & Ads',
    industry: 'Healthcare / Wellness',
    summary: 'A bespoke high-end clinic scheduler and premium editorial web application paired with Meta local lead generation campaigns.',
    beforeLabel: 'Weekly Inbound Inquiries',
    beforeValue: '15',
    afterLabel: 'Weekly Inbound Inquiries',
    afterValue: '75',
    beforeImageUrl: '',
    afterImageUrl: '',
    results: [
      { metric: 'Conversion Increase', value: '210%', subtext: 'Inbound booking scheduler rate' },
      { metric: 'Weekly Qualified Bookings', value: '75+', subtext: 'From highly aesthetic local ads' },
      { metric: 'Cost Per Acquisition', value: '-35%', subtext: 'Decreased waste through precise targeting' }
    ],
    challenge: 'Aura Aesthetic Clinic offered high-ticket facial therapies but had a slow, generic website that failed to reflect their clinic’s luxury atmosphere. They relied on phone inquiries, leading to massive friction and countless lost consultations.',
    strategy: 'We engineered a highly polished, editorial web application featuring a smooth custom visual scheduler that captures client preferences upfront. In parallel, we launched visually stunning local campaigns on Instagram highlighting before-and-after therapy videos with high-ticket branding layout cards.',
    deliverables: [
      'Bespoke React Consultation Scheduler App',
      'Premium Editorial Brand Strategy Guidelines',
      'Local Meta Lead Funnel Integration',
      'Before & After Video Campaign Directives'
    ],
    timeline: '2 Months',
    testimonialText: 'The custom web scheduler TechRooot designed for us is beautiful, fast, and does all the qualifying work. Our clinic calendars are entirely booked weeks in advance.',
    testimonialAuthor: 'Dr. Evelyn Thorne',
    testimonialRole: 'Medical Director & Founder',
    imageUrl: 'https://images.unsplash.com/photo-1579684389782-64d84b5e901a?auto=format&fit=crop&q=80&w=1200'
  },
  {
    id: 'apex-partners',
    title: 'Apex Tech Partners',
    clientName: 'Apex Capital & Tech Consulting',
    category: 'LinkedIn Management',
    industry: 'Technology / Consulting',
    summary: 'Scaling founder thought-leadership, securing high-ticket B2B incoming inquiries, and amplifying executive reach via structured carousels and narrative copy.',
    beforeLabel: 'Annual Inbound Leads',
    beforeValue: '2',
    afterLabel: 'Monthly Inbound Leads',
    afterValue: '14',
    beforeImageUrl: '',
    afterImageUrl: '',
    results: [
      { metric: 'Organic Content Views', value: '340k+', subtext: 'Within 90 days of launch' },
      { metric: 'Inbound Sales Calendars', value: '84', subtext: 'Directly sourced from DM triage' },
      { metric: 'LinkedIn Followers', value: '12.5k', subtext: 'Sustained authority audience base' }
    ],
    challenge: 'The managing partners of Apex Tech Partners possessed peerless expertise in scaling cloud architecture but had inactive personal social channels, lacking visual authority and failing to tap into the massive organic networking pipeline of LinkedIn.',
    strategy: 'We launched the TechRooot Executive Voice Program. We hosted bi-weekly audio extraction sessions, structured their insights into technical carousels and powerful narrative storytelling blocks, overhauled their headers with premium branding, and optimized their profile featured grid with call-to-actions.',
    deliverables: [
      'Voice Blueprint & Story Matrix Profile',
      'Custom slide deck presentation structures',
      '12 Monthly customized post releases with copywriting',
      'Private executive community messaging protocol'
    ],
    timeline: '6 Months',
    testimonialText: 'I was highly skeptical of outsourced content, but TechRooot captured my exact professional perspective. We have signed multiple five-figure agreements directly from LinkedIn DM inquiries.',
    testimonialAuthor: 'Sarah Chen',
    testimonialRole: 'Managing Partner',
    imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200'
  },
  {
    id: 'sustain-ai',
    title: 'SustainAI Automations',
    clientName: 'SustainAI Global Corp',
    category: 'AI Automation',
    industry: 'Technology / B2B',
    summary: 'Streamlining lead capture and customer-qualification pipelines with custom intelligent automated systems, cutting manual support time by 80%.',
    beforeLabel: 'Manual Lead Qual. Time',
    beforeValue: '4 hrs',
    afterLabel: 'AI Lead Qual. Time',
    afterValue: '90s',
    beforeImageUrl: '',
    afterImageUrl: '',
    results: [
      { metric: 'Response Compression', value: '90 Sec', subtext: 'From hours of delayed reply lag' },
      { metric: 'Operational Time Saved', value: '24 hrs/wk', subtext: 'Completely eliminated data copy chore' },
      { metric: 'Client Satisfaction Index', value: '98%', subtext: 'From immediate accurate replies' }
    ],
    challenge: 'SustainAI suffered from a bottleneck of inbound partner inquiries. Reps spent hours manually screening emails, checking CRM records, looking up company profiles, and writing basic custom drafts, creating critical lag and letting competitors sign prospects first.',
    strategy: 'We designed and integrated an automated AI qualification funnel. When a submission enters, a custom micro-pipeline scrapes public data, qualifies the lead based on custom parameters, inserts them into the CRM, generates a tailored brief, and drafts an instant customized reply ready for review.',
    deliverables: [
      'Interactive Custom Automation Blueprints',
      'Secure API Connection Pipeline (Make & Node)',
      'GPT-4o Custom Context Lead Qualifiers',
      'Slack Notification Reporting Bot Integration'
    ],
    timeline: '1 Month',
    testimonialText: 'TechRooot built us a digital back-office that works tirelessly 24/7. It transformed our lead routing, saving our reps endless copy-paste work.',
    testimonialAuthor: 'David Vance',
    testimonialRole: 'Chief of Operations',
    imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=1200'
  }
];

export const INITIAL_CLIENTS: Client[] = [
  {
    id: 'client-1',
    name: 'Nomad Nest Hospitality Group',
    industry: 'Hospitality & Luxury Real Estate',
    services: ['Airbnb Management', 'Branding', 'Meta Ads'],
    summary: 'A high-end vacation rental firm focused on creating serene modern nature getaways in remote landscapes.',
    timeline: '3 Months',
    results: 'Reached 94% occupancy rate, generated +$185 average daily rate boost, and secured a 4.96★ superhost review record.',
    testimonial: 'TechRooot is the ultimate partner for hands-off high-ticket rental success.'
  },
  {
    id: 'client-2',
    name: 'Aura Aesthetics Group',
    industry: 'Healthcare / Wellness',
    services: ['Website Development', 'Branding', 'Performance Marketing'],
    summary: 'A top-tier local aesthetic surgery clinic scaling high-ticket face & skincare consultation pathways.',
    timeline: '2 Months',
    results: '+210% booking conversion rate on custom React scheduler scheduler, and 75+ weekly qualified consultations generated.',
    testimonial: 'Our scheduling pipeline is booked for weeks. They understand luxury aesthetics.'
  },
  {
    id: 'client-3',
    name: 'Apex Capital & Tech Consulting',
    industry: 'B2B Consulting & Venture Capital',
    services: ['LinkedIn Management', 'Content Creation', 'Lead Generation'],
    summary: 'A premier mid-market scaling advisory firm specializing in enterprise SaaS and cloud modernization.',
    timeline: '6 Months',
    results: '+340k content views, 84 inbound executive meetings booked directly via DM triage.',
    testimonial: 'They captured my precise voice and turned active social presence into raw revenue.'
  },
  {
    id: 'client-4',
    name: 'SustainAI Global Corp',
    industry: 'B2B Enterprise Software',
    services: ['AI Automation', 'Workflow Engineering', 'Business Consulting'],
    summary: 'An enterprise software system provider integrating machine-learning workflows for manufacturing groups.',
    timeline: '1 Month',
    results: 'Eliminated 24 hours of human copy-paste work a week, compressing lead triage speed to 90 seconds.',
    testimonial: 'Their automated pipelines saved our sales team from manual Excel hell.'
  }
];

export const INITIAL_TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    authorName: 'Sarah Chen',
    role: 'Managing Partner',
    company: 'Apex Capital & Tech',
    text: 'TechRooot completely revolutionized our LinkedIn game. We signed three enterprise clients in two months of their executive positioning package. Their writers capture my exact professional voice, and the slide carousels they build look like editorial art.',
    rating: 5,
    platform: 'LinkedIn'
  },
  {
    id: 'test-2',
    authorName: 'Marcus Vance',
    role: 'Founder',
    company: 'Nomad Nest Hospitality',
    text: 'Our Airbnb was struggling with low search ranks and inconsistent seasonal bookings. TechRooot took over dynamic listing optimization, visual media direction, and luxury hospitality branding. Our bookings exploded to 94% occupancy, and guest reviews have never been higher.',
    rating: 5,
    platform: 'Google'
  },
  {
    id: 'test-3',
    authorName: 'Dr. Evelyn Thorne',
    role: 'Medical Director',
    company: 'Aura Aesthetic Clinic',
    text: 'The speed, responsiveness, and sheer quality of their engineering are second to none. Our new custom scheduler is beautiful, fast, and captures patient concerns upfront. It has dramatically reduced our front-desk friction.',
    rating: 5,
    platform: 'Clutch'
  },
  {
    id: 'test-4',
    authorName: 'David Vance',
    role: 'Chief of Operations',
    company: 'SustainAI Global',
    text: 'The custom AI automations they engineered have streamlined our sales routing completely. They saved our team over 24 hours of manual data entry every single week. Highly professional team and clean, maintainable systems.',
    rating: 5,
    platform: 'Direct'
  }
];

export const INITIAL_BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    title: 'How We Scaled a Boutique Airbnb in Kyoto to 94% Occupancy in 90 Days',
    category: 'Airbnb Management',
    author: 'TechRooot Growth Team',
    readTime: '6 min read',
    publishedAt: 'June 18, 2026',
    summary: 'A deep dive into dynamic rate multipliers, local narrative staging, and algorithmic seo optimization tricks that beat out five-star competitors.',
    content: `Scaling boutique hospitality requires looking beyond basic listing checkboxes. Here is the step-by-step roadmap we executed:
    
    1. Narrative Interior Staging: We shifted from plain stock furniture to local heritage styling accents that stand out on mobile screens.
    2. Algorithmic SEO: Airbnb values click-through rates and message reply speeds. We optimized listing titles with high-intent keywords and integrated auto-responders.
    3. Real-Time Pricing Rules: We linked listing availability with localized weather reports and city concert tickets to scale daily pricing automatically, maximizing total booking value.`,
    imageUrl: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'blog-2',
    title: 'The LinkedIn Creator Formula: From 0 to 10k Followers for B2B Executives',
    category: 'LinkedIn Growth',
    author: 'TechRooot Copywriting Team',
    readTime: '5 min read',
    publishedAt: 'May 24, 2026',
    summary: 'The precise messaging matrices, profile landing page tweaks, and scheduling frequencies that establish absolute executive authority.',
    content: `LinkedIn is the ultimate high-ticket lead channel, but generic quotes fail to convert. Our system is built on three pillars:
    
    - Pillar 1: Audio Voice Extraction. We interview founders for 15 minutes a week and capture their authentic unfiltered perspectives.
    - Pillar 2: The Scroll-Stopping Carousel. Visual slide carousels see 4x more engagement than plain text. We package data into editorial-grade sliders.
    - Pillar 3: Profile Funnel Optimization. We convert profile pageviews to leads by installing a specific, friction-free scheduler booking link in the featured panel.`,
    imageUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'blog-3',
    title: 'Why Custom React Web Apps Outconvert Template Sites for High-Ticket Brands',
    category: 'Web Development',
    author: 'TechRooot Engineering Team',
    readTime: '8 min read',
    publishedAt: 'April 12, 2026',
    summary: 'Unpacking the massive cost of template bloat, poor mobile performance, and why smooth custom-tailored user experience builds immediate customer trust.',
    content: `First impressions are visual, but trust is interactive. Slow-loading template themes fail because of technical bloat:
    
    - Performance Cost: Every extra second of load time cuts conversion rates by 20%. Custom React sites load in under 600ms.
    - Branding Consistency: Template themes force your brand into a cookie-cutter grid. Custom code allows editorial text layouts, elegant padding, and micro-interactions that communicate quality.
    - Custom Interactive Tools: High-ticket visitors don't want static forms. They expect custom price calculators, consultation planners, and dynamic portfolios that make engagement satisfying.`,
    imageUrl: 'https://images.unsplash.com/photo-1579684389782-64d84b5e901a?auto=format&fit=crop&q=80&w=600'
  }
];

export const INDUSTRIES: Industry[] = [
  {
    id: 'hospitality',
    name: 'Hospitality & Luxury Rentals',
    iconName: 'Hotel',
    description: 'Elevating boutique stays, luxury villas, and rental portfolios through visual branding, Superhost management, and direct booking web funnels.',
    servicesProvided: ['Airbnb Management', 'Website Development', 'Branding', 'Performance Marketing'],
    clientHighlights: ['Nomad Nest Hospitality Group', 'Kyoto Forest Villa', 'Aura Luxury Escapes']
  },
  {
    id: 'healthcare',
    name: 'Healthcare & Aesthetic Wellness',
    iconName: 'Activity',
    description: 'Polishing high-end private aesthetic clinics, modern dental clinics, and medical consultants with high-conversion schedulers and local acquisition systems.',
    servicesProvided: ['Website Development', 'Performance Marketing', 'Lead Generation', 'Branding'],
    clientHighlights: ['Aura Aesthetic Clinic', 'Vance Dental Group', 'Thorne Face Therapy']
  },
  {
    id: 'startups',
    name: 'Startups & Technology Groups',
    iconName: 'Rocket',
    description: 'Bootstrapping fast-growing software providers, AI platforms, and technical agencies with clean investor slide-decks, websites, and custom automations.',
    servicesProvided: ['Website Development', 'AI Automation', 'Startup Consulting', 'LinkedIn Management'],
    clientHighlights: ['SustainAI Global Corp', 'Helix SaaS', 'Alpha Venture Partners']
  },
  {
    id: 'creators',
    name: 'Creators & Personal Brands',
    iconName: 'Sparkles',
    description: 'Transforming technical executives, creators, and high-ticket business consultants into verified niche authorities via premium content pipelines.',
    servicesProvided: ['LinkedIn Management', 'Content Creation', 'Branding', 'Lead Generation'],
    clientHighlights: ['Sarah Chen Executive Advisory', 'The VC Insider', 'Marcus Tech Story']
  }
];

export const INITIAL_LEADS: Lead[] = [
  {
    id: 'lead-1',
    name: 'Rebecca Alvarez',
    email: 'rebecca@vistascapes.com',
    company: 'VistaScapes Luxury Rentals',
    serviceType: 'Airbnb Management',
    message: 'We manage 8 luxury rental cabins in Utah and want to optimize our pricing structures and direct-booking channels. Your work with Nomad Nest looks highly relevant.',
    status: 'New',
    timestamp: '2026-06-29T09:15:00-07:00'
  },
  {
    id: 'lead-2',
    name: 'Arthur Pendelton',
    email: 'arthur@nexuscorp.io',
    company: 'Nexus SaaS Integration',
    serviceType: 'LinkedIn Management',
    message: 'Looking to overhaul our executive personal brands to support our upcoming Series A fundraising round. Need a robust and reliable thought-leadership partner.',
    status: 'In Progress',
    timestamp: '2026-06-28T14:22:00-07:00'
  }
];

export const INITIAL_SUBSCRIPTIONS: StripeSubscription[] = [
  {
    id: 'sub-1',
    clientName: 'Nomad Nest Hospitality',
    email: 'marcus@nomadnest.co',
    planName: 'Elite Growth Package',
    amount: 3450,
    interval: 'monthly',
    status: 'active',
    createdAt: '2026-04-10'
  },
  {
    id: 'sub-2',
    clientName: 'Aura Aesthetics',
    email: 'evelyn@auraclinic.com',
    planName: 'Omnichannel Scale Package',
    amount: 4800,
    interval: 'monthly',
    status: 'active',
    createdAt: '2026-05-15'
  },
  {
    id: 'sub-3',
    clientName: 'Apex Capital',
    email: 'sarah@apexcap.io',
    planName: 'Executive Voice Pro',
    amount: 2500,
    interval: 'monthly',
    status: 'active',
    createdAt: '2026-06-01'
  }
];

export const INITIAL_ANALYTICS: AnalyticsStats = {
  visitors: 12450,
  bounceRate: 38.4,
  avgSession: 195, // 3 mins 15s
  totalLeads: 142,
  activeSubscriptions: 3,
  monthlyRevenue: 10750,
  visitorsHistory: [
    { day: 'Mon', count: 1200 },
    { day: 'Tue', count: 1540 },
    { day: 'Wed', count: 1680 },
    { day: 'Thu', count: 1890 },
    { day: 'Fri', count: 1720 },
    { day: 'Sat', count: 1100 },
    { day: 'Sun', count: 1320 }
  ],
  leadsHistory: [
    { month: 'Jan', count: 18 },
    { month: 'Feb', count: 25 },
    { month: 'Mar', count: 31 },
    { month: 'Apr', count: 48 },
    { month: 'May', count: 52 },
    { month: 'Jun', count: 68 }
  ],
  servicesBreakdown: [
    { name: 'Website Dev', value: 35 },
    { name: 'Airbnb Mgmt', value: 25 },
    { name: 'LinkedIn Growth', value: 20 },
    { name: 'Ads & Marketing', value: 15 },
    { name: 'AI Automation', value: 5 }
  ],
  trafficSources: [
    { name: 'Direct/Search', value: 45 },
    { name: 'LinkedIn Organic', value: 30 },
    { name: 'Meta/Google Ads', value: 15 },
    { name: 'Referral/Clutch', value: 10 }
  ]
};

// LocalStorage helpers
export function loadCMSData<T>(key: string, defaultValue: T): T {
  try {
    const saved = localStorage.getItem(`techrooot_cms_${key}`);
    return saved ? JSON.parse(saved) : defaultValue;
  } catch (e) {
    return defaultValue;
  }
}

export function saveCMSData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(`techrooot_cms_${key}`, JSON.stringify(data));
  } catch (e) {
    console.error('Error saving CMS state:', e);
  }
}
