/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Project {
  id: string;
  title: string;
  clientName: string;
  category: string;
  industry: string;
  summary: string;
  beforeLabel?: string;
  beforeValue?: string;
  afterLabel?: string;
  afterValue?: string;
  beforeImageUrl?: string;
  afterImageUrl?: string;
  results: {
    metric: string;
    value: string;
    subtext: string;
  }[];
  challenge: string;
  strategy: string;
  deliverables: string[];
  timeline: string;
  testimonialText?: string;
  testimonialAuthor?: string;
  testimonialRole?: string;
  imageUrl: string;
  content?: string;
}

export interface Client {
  id: string;
  name: string;
  logoUrl?: string;
  industry: string;
  services: string[];
  summary: string;
  timeline: string;
  results: string;
  testimonial?: string;
}

export interface Service {
  id: string;
  title: string;
  category: 'growth' | 'marketing' | 'tech' | 'creative' | 'consulting';
  description: string;
  fullDetails: string;
  whoIsItFor: string;
  benefits: string[];
  process: {
    step: string;
    title: string;
    description: string;
  }[];
  deliverables: string[];
  sampleWorkSummary: string;
  faqs: {
    question: string;
    answer: string;
  }[];
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  author: string;
  readTime: string;
  publishedAt: string;
  summary: string;
  content: string;
  imageUrl: string;
}

export interface Testimonial {
  id: string;
  authorName: string;
  role: string;
  company: string;
  text: string;
  rating: number;
  platform: 'LinkedIn' | 'Google' | 'Clutch' | 'Direct';
  avatarUrl?: string;
  screenshotUrl?: string;
}

export interface Industry {
  id: string;
  name: string;
  iconName: string;
  description: string;
  servicesProvided: string[];
  clientHighlights: string[];
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  company: string;
  serviceType: string;
  message: string;
  status: 'New' | 'In Progress' | 'Contacted' | 'Archived';
  timestamp: string;
}

export interface StripeSubscription {
  id: string;
  clientName: string;
  email: string;
  planName: string;
  amount: number;
  interval: 'monthly' | 'yearly';
  status: 'active' | 'canceled';
  createdAt: string;
}

export interface AnalyticsStats {
  visitors: number;
  bounceRate: number;
  avgSession: number;
  totalLeads: number;
  activeSubscriptions: number;
  monthlyRevenue: number;
  visitorsHistory: { day: string; count: number }[];
  leadsHistory: { month: string; count: number }[];
  servicesBreakdown: { name: string; value: number }[];
  trafficSources: { name: string; value: number }[];
}
